-- ============================================================
-- CSDL HE THONG SIEU THI POS
-- Cach dung: Mo phpMyAdmin (http://localhost/phpmyadmin) > Import file nay
-- hoac chay lenh: mysql -u root -p < pos_db.sql
-- Luu y: neu dung spring.jpa.hibernate.ddl-auto=update thi chi can tao
-- database rong "pos_db", Hibernate se tu tao bang. File nay danh cho ai
-- muon co san du lieu mau de test ngay.
-- ============================================================

CREATE DATABASE IF NOT EXISTS pos_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pos_db;

-- ================= BANG TAI KHOAN NGUOI DUNG =================
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    role VARCHAR(20) NOT NULL DEFAULT 'STAFF',
    phone VARCHAR(20),
    email VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO users (username, password, full_name, role, phone, email) VALUES
('admin', '123456', 'Quan Tri Vien', 'ADMIN', '0900000000', 'admin@pos.vn'),
('nhanvien1', '123456', 'Nguyen Van A', 'STAFF', '0911111111', 'nva@pos.vn');

-- ================= DANH MUC SAN PHAM =================
CREATE TABLE IF NOT EXISTS categories (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255)
) ENGINE=InnoDB;

INSERT INTO categories (name, description) VALUES
('Do uong', 'Nuoc ngot, nuoc ep, nuoc suoi'),
('Thuc pham', 'Mi goi, snack, do an nhe'),
('Hoa my pham', 'Dau goi, sua tam, my pham');

-- ================= NHA CUNG CAP =================
CREATE TABLE IF NOT EXISTS suppliers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255)
) ENGINE=InnoDB;

INSERT INTO suppliers (name, phone, address) VALUES
('Cong ty TNHH Coca-Cola VN', '0281234567', 'TP.HCM'),
('Cong ty Acecook Viet Nam', '0287654321', 'Ha Noi'),
('Cong ty Unilever VN', '0289998888', 'TP.HCM');

-- ================= SAN PHAM =================
CREATE TABLE IF NOT EXISTS products (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    barcode VARCHAR(50) UNIQUE,
    name VARCHAR(200) NOT NULL,
    category_id BIGINT,
    supplier_id BIGINT,
    price DECIMAL(15,2) NOT NULL DEFAULT 0,
    quantity INT NOT NULL DEFAULT 0,
    unit VARCHAR(30),
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO products (barcode, name, category_id, supplier_id, price, quantity, unit) VALUES
('8930000000001', 'Mi tom Hao Hao', 2, 2, 4000, 500, 'Goi'),
('8930000000002', 'Nuoc ngot Coca-Cola 320ml', 1, 1, 10000, 199, 'Lon'),
('8930000000003', 'Dau goi Clear 180ml', 3, 3, 65000, 49, 'Chai'),
('2112413454623', 'Bim Bim oiShi hanh tay', 2, 2, 5000, 300, 'Goi'),
('08327468264243', 'Nuoc Cam', 1, 1, 10000, 300, 'Chai');

-- ================= KHACH HANG =================
CREATE TABLE IF NOT EXISTS customers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255)
) ENGINE=InnoDB;

INSERT INTO customers (name, phone, address) VALUES
('Khach le', '', ''),
('Tran Thi B', '0933333333', 'Quan 1, TP.HCM');

-- ================= HOA DON BAN HANG =================
CREATE TABLE IF NOT EXISTS invoices (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    customer_id BIGINT,
    user_id BIGINT,
    invoice_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS invoice_details (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    invoice_id BIGINT NOT NULL,
    product_id BIGINT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(15,2) NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- ================= PHIEU NHAP HANG =================
CREATE TABLE IF NOT EXISTS stock_imports (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    supplier_id BIGINT,
    user_id BIGINT,
    import_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock_import_details (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    stock_import_id BIGINT NOT NULL,
    product_id BIGINT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(15,2) NOT NULL,
    FOREIGN KEY (stock_import_id) REFERENCES stock_imports(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- ================= PHAN CONG NHAN VIEN QUAN LY DANH MUC =================
CREATE TABLE IF NOT EXISTS category_assignments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    category_id BIGINT NOT NULL,
    assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    UNIQUE KEY uq_user_category (user_id, category_id)
) ENGINE=InnoDB;

-- Vi du: nhan vien "nhanvien1" (id=2) duoc phan cong quan ly danh muc "Do uong" (id=1)
INSERT INTO category_assignments (user_id, category_id) VALUES (2, 1);

-- ================= DE XUAT NHAP HANG TU NHAN VIEN =================
CREATE TABLE IF NOT EXISTS restock_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    product_id BIGINT NOT NULL,
    proposed_by BIGINT,
    quantity INT NOT NULL,
    note VARCHAR(500),
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    processed_by BIGINT,
    processed_at DATETIME,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (proposed_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (processed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ================= DU LIEU MAU: 2 HOA DON (khop voi anh bao cao doanh thu) =================
INSERT INTO invoices (customer_id, user_id, invoice_time, total_amount) VALUES
(1, 2, '2026-07-05 21:11:00', 65000),
(1, 2, '2026-07-05 22:22:00', 10000);

INSERT INTO invoice_details (invoice_id, product_id, quantity, price) VALUES
(1, 3, 1, 65000),
(2, 2, 1, 10000);

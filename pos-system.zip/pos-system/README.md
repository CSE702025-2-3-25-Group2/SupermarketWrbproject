# HỆ THỐNG QUẢN LÝ BÁN HÀNG SIÊU THỊ (POS)

Backend: **Spring Boot 3 + Spring Data JPA + MySQL**
Frontend: **HTML/CSS/JavaScript thuần** (không cần Node.js, chạy thẳng từ Spring Boot)
IDE: **IntelliJ IDEA**
Database: **MySQL qua XAMPP**

---

## 1. CẤU TRÚC DỰ ÁN

```
pos-system/
├── pom.xml
├── database/
│   └── pos_db.sql              <-- File SQL tạo database + dữ liệu mẫu
└── src/main/
    ├── java/com/pos/
    │   ├── PosApplication.java
    │   ├── config/              (CORS, xử lý lỗi chung)
    │   ├── entity/               (Product, Category, Supplier, Customer,
    │   │                          User, Invoice, InvoiceDetail,
    │   │                          StockImport, StockImportDetail)
    │   ├── repository/           (Spring Data JPA repositories)
    │   ├── service/              (Xử lý nghiệp vụ: bán hàng, nhập kho,
    │   │                          báo cáo doanh thu...)
    │   ├── controller/           (REST API - /api/...)
    │   └── dto/                  (Request/Response objects)
    └── resources/
        ├── application.properties
        └── static/                (Giao diện web)
            ├── login.html         (Trang đăng nhập)
            ├── admin.html         (Trang quản trị: kho, danh mục, NCC,
            │                       nhập hàng, khách hàng, hóa đơn, nhân viên)
            ├── pos.html            (Màn hình quầy bán)
            ├── report.html         (Báo cáo doanh thu & thống kê)
            ├── css/style.css
            └── js/ (common.js, admin.js, pos.js, report.js)
```

---

## 2. CÀI ĐẶT XAMPP & TẠO DATABASE

1. Cài đặt và khởi động **XAMPP**, bật **Apache** và **MySQL** trong XAMPP Control Panel.
2. Mở trình duyệt vào `http://localhost/phpmyadmin`.
3. Vào tab **Import** → chọn file `database/pos_db.sql` trong dự án → nhấn **Go**.
   - Thao tác này sẽ tự tạo database `pos_db` và các bảng, kèm dữ liệu mẫu
     (2 tài khoản, 5 sản phẩm, 2 hóa đơn mẫu... giống với ảnh bạn gửi).
4. Tài khoản đăng nhập mẫu:
   - **Quản trị viên**: `admin` / `123456`
   - **Nhân viên**: `nhanvien1` / `123456`

> Nếu bạn không muốn import file SQL, chỉ cần tạo database rỗng tên `pos_db`
> trong phpMyAdmin — Spring Boot sẽ tự động tạo bảng nhờ cấu hình
> `spring.jpa.hibernate.ddl-auto=update`. Khi đó bạn cần tự thêm dữ liệu
> (vd. tài khoản admin) qua giao diện hoặc phpMyAdmin.

---

## 3. MỞ DỰ ÁN BẰNG INTELLIJ IDEA

1. Mở IntelliJ IDEA → **File → Open** → chọn thư mục `pos-system` (thư mục
   chứa file `pom.xml`).
2. IntelliJ sẽ tự nhận diện đây là dự án Maven và tải các thư viện phụ thuộc
   (cần có kết nối Internet lần đầu để Maven tải các gói trong `pom.xml`).
3. Cài **plugin Lombok** cho IntelliJ (Settings → Plugins → tìm "Lombok" →
   Install), sau đó bật **Annotation Processing**:
   Settings → Build, Execution, Deployment → Compiler → Annotation Processors
   → tick **Enable annotation processing**.
4. Kiểm tra file `src/main/resources/application.properties`:
   - `spring.datasource.username=root`
   - `spring.datasource.password=` (mặc định XAMPP không có mật khẩu; nếu
     bạn có đặt mật khẩu cho MySQL thì cập nhật lại dòng này).
5. Chạy dự án: mở file `PosApplication.java` → nhấn nút ▶ (Run) hoặc
   `Shift + F10`.
6. Khi console hiện dòng "HE THONG SIEU THI POS DA KHOI DONG!" nghĩa là
   backend đã chạy thành công tại `http://localhost:8080`.

---

## 4. SỬ DỤNG HỆ THỐNG

Mở trình duyệt vào: **http://localhost:8080**
(sẽ tự chuyển đến trang đăng nhập `login.html`)

- Đăng nhập bằng `admin` / `123456` → vào thẳng **trang quản trị**
  (Kho hàng, Danh mục & Đối tác, Nhập hàng kho, Khách hàng, Lịch sử hóa đơn,
  Quản lý nhân viên).
- Đăng nhập bằng `nhanvien1` / `123456` → vào thẳng **màn hình quầy bán**
  (chỉ có quyền bán hàng, không truy cập được trang quản trị).
- Từ trang quản trị có thể bấm **"Xem báo cáo doanh thu"** để vào trang
  thống kê doanh thu theo ngày/tháng/năm, sản phẩm bán chạy, tồn kho.

---

## 5. DANH SÁCH CHỨC NĂNG ĐÃ HOÀN THIỆN

| Chức năng | Vị trí |
|---|---|
| Đăng nhập, phân quyền (Quản lý / Nhân viên) | `login.html`, mọi trang |
| CRUD sản phẩm + tìm kiếm theo tên/mã vạch | `admin.html` → Kho Sản Phẩm |
| CRUD danh mục sản phẩm | `admin.html` → Danh Mục & Đối Tác |
| CRUD nhà cung cấp | `admin.html` → Danh Mục & Đối Tác |
| CRUD khách hàng + tìm kiếm | `admin.html` → Khách Hàng |
| CRUD nhân viên/tài khoản, phân quyền | `admin.html` → Quản Lý Nhân Viên |
| Lập phiếu nhập hàng → **tự động cộng tồn kho** | `admin.html` → Nhập Hàng Kho |
| Bán hàng, lập hóa đơn → **tự động trừ tồn kho** | `pos.html` |
| Xem lịch sử & chi tiết hóa đơn | `admin.html` → Lịch Sử Hóa Đơn |
| Thống kê doanh thu theo ngày/tháng/năm | `report.html` |
| Thống kê sản phẩm bán chạy | `report.html` |
| Thống kê tồn kho / cảnh báo sắp hết hàng | `report.html` |

---

## 6. CHỨC NĂNG BỔ SUNG CHO NHÂN VIÊN (theo yêu cầu giảng viên)

Truy cập qua nút **"🧑‍💼 Khu vực nhân viên"** ở màn hình quầy bán (`pos.html`),
hoặc trực tiếp `http://localhost:8080/staff.html`.

| Chức năng | Trang / API |
|---|---|
| Admin phân công nhân viên quản lý 1 hoặc nhiều danh mục sản phẩm | `admin.html` → tab **Phân Công Nhân Viên**; API `POST /api/assignments` |
| Nhân viên xem kho hàng thuộc danh mục được phân công, cảnh báo tồn kho thấp | `staff.html` → tab **Kho Được Phân Công**; API `GET /api/products/by-categories` |
| Nhân viên xem báo cáo doanh thu **theo ngày / tuần / tháng**, chỉ tính trên danh mục của mình | `staff.html` → tab **Báo Cáo Của Tôi**; API `GET /api/reports/staff-revenue` |
| Nhân viên gửi đề xuất nhập hàng cho admin | `staff.html` → tab **Đề Xuất Nhập Hàng**; API `POST /api/restock-requests` |
| Admin duyệt / từ chối đề xuất — khi duyệt, hệ thống **tự động tạo phiếu nhập kho và cộng tồn kho** | `admin.html` → tab **Duyệt Đề Xuất Nhập Hàng**; API `PUT /api/restock-requests/{id}/approve` |

**Model dữ liệu mới:**
- `category_assignments` (user_id, category_id) — quan hệ nhiều-nhiều giữa nhân viên và danh mục.
- `restock_requests` (product_id, proposed_by, quantity, note, status: PENDING/APPROVED/REJECTED, processed_by, processed_at).

**Luồng duyệt đề xuất** tái sử dụng `StockImportService.createImport()` đã có sẵn — khi
admin bấm "Duyệt", backend tự tạo 1 `StockImport` với sản phẩm/số lượng từ đề xuất,
qua đó tồn kho được cộng thêm đúng như một phiếu nhập hàng thông thường, đồng thời
vẫn lưu lại lịch sử trong "Lịch Sử Nhập Hàng" ở trang admin.

---

## 7. GHI CHÚ KỸ THUẬT

- **Tự động cập nhật tồn kho**: xử lý trong `SaleService.createSale()` (trừ
  kho khi bán) và `StockImportService.createImport()` (cộng kho khi nhập),
  đều dùng `@Transactional` để đảm bảo toàn vẹn dữ liệu.
- **Xác thực**: đơn giản hoá theo dạng học tập — không dùng Spring Security,
  frontend lưu thông tin đăng nhập vào `sessionStorage` sau khi gọi API
  `/api/auth/login` thành công. Có thể nâng cấp lên Spring Security +
  JWT sau này nếu cần bảo mật cao hơn.
- **CORS**: đã cấu hình mở cho `/api/**` trong `CorsConfig.java`.
- Toàn bộ số tiền hiển thị định dạng kiểu Việt Nam (vd: `65.000 đ`).

// ============================================================
// STAFF.JS - Kho duoc phan cong, bao cao rieng, de xuat nhap hang
// ============================================================

let staffUser = requireLogin();
const contentArea = document.getElementById('contentArea');
const modalOverlay = document.getElementById('modalOverlay');
const modalBox = document.getElementById('modalBox');

let myCategories = [];   // danh muc duoc phan cong quan ly
let myProducts = [];     // san pham thuoc cac danh muc do

function openModal(html) { modalBox.innerHTML = html; modalOverlay.classList.add('show'); }
function closeModal() { modalOverlay.classList.remove('show'); modalBox.innerHTML = ''; }
modalOverlay.addEventListener('click', (e) => { if (e.target === modalOverlay) closeModal(); });

document.querySelectorAll('.menu-item').forEach(item => {
    item.addEventListener('click', () => {
        document.querySelectorAll('.menu-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        renderTab(item.dataset.tab);
    });
});

function renderTab(tab) {
    if (tab === 'mystock') renderMyStockTab();
    else if (tab === 'myreport') renderMyReportTab();
    else if (tab === 'restock') renderRestockTab();
}

async function loadMyCategories() {
    myCategories = await api.get('/assignments/user/' + staffUser.userId);
}

// ============================================================
// TAB 1: KHO DUOC PHAN CONG
// ============================================================
async function renderMyStockTab() {
    contentArea.innerHTML = `<h2>Kho Hàng Được Phân Công</h2><div class="panel" id="myStockPanel">Đang tải...</div>`;
    await loadMyCategories();

    const panel = document.getElementById('myStockPanel');
    if (myCategories.length === 0) {
        panel.innerHTML = `<div class="empty-state">Bạn chưa được Quản Trị Viên phân công quản lý danh mục sản phẩm nào.</div>`;
        return;
    }

    const categoryIds = myCategories.map(c => c.id);
    myProducts = await api.get('/products/by-categories?' + categoryIds.map(id => 'categoryIds=' + id).join('&'));

    const lowStockCount = myProducts.filter(p => p.quantity <= 10).length;

    panel.innerHTML = `
        <div style="margin-bottom:14px;">
            <b>Danh mục được phân công:</b>
            ${myCategories.map(c => `<span class="badge badge-gray" style="margin-right:6px;">${c.name}</span>`).join('')}
        </div>
        ${lowStockCount > 0 ? `<div class="login-error" style="display:block;">⚠️ Có ${lowStockCount} sản phẩm sắp hết hàng (tồn kho ≤ 10). Hãy cân nhắc tạo đề xuất nhập hàng.</div>` : ''}
        <table>
            <thead><tr><th>Sản phẩm</th><th>Mã vạch</th><th>Giá bán</th><th>Tồn kho</th><th>Đơn vị</th><th>Trạng thái</th></tr></thead>
            <tbody>
            ${myProducts.map(p => `
                <tr>
                    <td>${p.name}</td><td>${p.barcode || ''}</td>
                    <td class="price-blue">${formatMoney(p.price)}</td>
                    <td><span class="badge ${p.quantity <= 10 ? 'badge-gray' : 'badge-green'}">${p.quantity}</span></td>
                    <td>${p.unit || ''}</td>
                    <td>${p.quantity <= 10 ? '⚠️ Sắp hết hàng' : '✅ Còn hàng'}</td>
                </tr>`).join('') || `<tr><td colspan="6" class="empty-state">Không có sản phẩm nào trong danh mục được phân công.</td></tr>`}
            </tbody>
        </table>`;
}

// ============================================================
// TAB 2: BAO CAO CUA TOI (theo ngay/tuan/thang)
// ============================================================
async function renderMyReportTab() {
    contentArea.innerHTML = `
        <h2>Báo Cáo Doanh Thu Của Tôi</h2>
        <div class="panel">
            <div class="filter-row">
                <div class="form-group"><label>Từ ngày</label><input type="date" id="myFromDate"></div>
                <div class="form-group"><label>Đến ngày</label><input type="date" id="myToDate"></div>
                <div class="form-group" style="max-width:180px;">
                    <label>Nhóm theo</label>
                    <select id="myGroupBy">
                        <option value="day">Ngày</option>
                        <option value="week">Tuần</option>
                        <option value="month">Tháng</option>
                    </select>
                </div>
                <button class="btn btn-dark" style="height:44px" onclick="loadMyReport()">🧮 Xem báo cáo</button>
            </div>
        </div>
        <div class="panel">
            <h3>📊 Doanh thu theo danh mục được phân công</h3>
            <div id="myReportWrap">Chọn khoảng thời gian và bấm "Xem báo cáo".</div>
        </div>`;

    const today = new Date().toISOString().slice(0, 10);
    document.getElementById('myFromDate').value = today;
    document.getElementById('myToDate').value = today;
    await loadMyCategories();
    loadMyReport();
}

async function loadMyReport() {
    const wrap = document.getElementById('myReportWrap');
    if (myCategories.length === 0) {
        wrap.innerHTML = `<div class="empty-state">Bạn chưa được phân công quản lý danh mục nào nên chưa có dữ liệu báo cáo.</div>`;
        return;
    }
    const from = document.getElementById('myFromDate').value;
    const to = document.getElementById('myToDate').value;
    const groupBy = document.getElementById('myGroupBy').value;
    const categoryIds = myCategories.map(c => c.id);

    try {
        const query = categoryIds.map(id => 'categoryIds=' + id).join('&') + `&from=${from}&to=${to}&groupBy=${groupBy}`;
        const data = await api.get('/reports/staff-revenue?' + query);
        const entries = Object.entries(data);
        const total = entries.reduce((sum, [, v]) => sum + Number(v), 0);

        wrap.innerHTML = `
            <div class="cart-total" style="font-size:18px; margin-bottom:16px;">
                <span>Tổng doanh thu (danh mục của bạn)</span><span class="amount">${formatMoney(total)}</span>
            </div>
            ${entries.length === 0 ? `<div class="empty-state">Không có doanh số nào trong khoảng thời gian này.</div>` : `
            <table>
                <thead><tr><th>Kỳ báo cáo</th><th style="text-align:right">Doanh thu</th></tr></thead>
                <tbody>
                ${entries.map(([key, val]) => `
                    <tr><td>${key}</td><td class="text-green" style="text-align:right">${formatMoney(val)}</td></tr>`).join('')}
                </tbody>
            </table>`}`;
    } catch (err) {
        wrap.innerHTML = `<div class="empty-state">Lỗi tải báo cáo: ${err.message}</div>`;
    }
}

// ============================================================
// TAB 3: DE XUAT NHAP HANG
// ============================================================
async function renderRestockTab() {
    contentArea.innerHTML = `
        <h2>Đề Xuất Nhập Hàng</h2>
        <div class="panel">
            <h3>📝 Tạo đề xuất mới</h3>
            <div id="restockFormWrap">Đang tải...</div>
        </div>
        <div class="panel">
            <h3>📋 Lịch sử đề xuất của tôi</h3>
            <div id="restockHistoryWrap">Đang tải...</div>
        </div>`;

    await loadMyCategories();
    const formWrap = document.getElementById('restockFormWrap');

    if (myCategories.length === 0) {
        formWrap.innerHTML = `<div class="empty-state">Bạn chưa được phân công quản lý danh mục nào nên chưa thể đề xuất nhập hàng.</div>`;
    } else {
        const categoryIds = myCategories.map(c => c.id);
        myProducts = await api.get('/products/by-categories?' + categoryIds.map(id => 'categoryIds=' + id).join('&'));
        formWrap.innerHTML = `
            <div class="filter-row">
                <div class="form-group">
                    <label>Sản phẩm</label>
                    <select id="restockProduct">
                        ${myProducts.map(p => `<option value="${p.id}">${p.name} (Tồn: ${p.quantity})</option>`).join('')}
                    </select>
                </div>
                <div class="form-group" style="max-width:140px;">
                    <label>Số lượng đề xuất</label>
                    <input type="number" id="restockQty" min="1" value="50">
                </div>
                <div class="form-group" style="flex:2;">
                    <label>Ghi chú</label>
                    <input id="restockNote" placeholder="Lý do đề xuất (VD: sắp hết hàng, chuẩn bị cao điểm...)">
                </div>
                <button class="btn btn-green" style="height:44px" onclick="submitRestockRequest()">📤 Gửi đề xuất</button>
            </div>`;
    }

    await loadRestockHistory();
}

async function submitRestockRequest() {
    const productId = Number(document.getElementById('restockProduct').value);
    const quantity = Number(document.getElementById('restockQty').value);
    const note = document.getElementById('restockNote').value.trim();

    if (!productId || quantity <= 0) { showToast('Vui lòng chọn sản phẩm và số lượng hợp lệ', 'error'); return; }

    try {
        await api.post('/restock-requests', { productId, userId: staffUser.userId, quantity, note });
        showToast('Đã gửi đề xuất nhập hàng cho Quản Trị Viên');
        document.getElementById('restockNote').value = '';
        loadRestockHistory();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function loadRestockHistory() {
    const wrap = document.getElementById('restockHistoryWrap');
    const list = await api.get('/restock-requests/user/' + staffUser.userId);

    const statusBadge = (status) => {
        if (status === 'APPROVED') return `<span class="badge badge-green">Đã duyệt</span>`;
        if (status === 'REJECTED') return `<span class="badge" style="background:#dc2626;">Từ chối</span>`;
        return `<span class="badge" style="background:#eab308;color:#1a1a1a;">Đang chờ duyệt</span>`;
    };

    wrap.innerHTML = list.length === 0 ? `<div class="empty-state">Bạn chưa gửi đề xuất nào.</div>` : `
        <table>
            <thead><tr><th>Sản phẩm</th><th>Số lượng</th><th>Ghi chú</th><th>Ngày gửi</th><th>Trạng thái</th></tr></thead>
            <tbody>
            ${list.map(r => `
                <tr>
                    <td>${r.product.name}</td><td>${r.quantity}</td><td>${r.note || ''}</td>
                    <td>${formatDateTime(r.createdAt)}</td>
                    <td>${statusBadge(r.status)}</td>
                </tr>`).join('')}
            </tbody>
        </table>`;
}

// ------------------ INIT ------------------
if (staffUser) renderMyStockTab();

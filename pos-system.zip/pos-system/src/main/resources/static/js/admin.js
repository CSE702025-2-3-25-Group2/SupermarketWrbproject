// ============================================================
// ADMIN.JS - Logic cho toan bo trang quan tri
// ============================================================

let currentUser = requireAdmin();
const contentArea = document.getElementById('contentArea');
const modalOverlay = document.getElementById('modalOverlay');
const modalBox = document.getElementById('modalBox');

let cache = { categories: [], suppliers: [], products: [], customers: [], users: [] };

// ------------------ MODAL HELPERS ------------------
function openModal(html) {
    modalBox.innerHTML = html;
    modalOverlay.classList.add('show');
}
function closeModal() {
    modalOverlay.classList.remove('show');
    modalBox.innerHTML = '';
}
modalOverlay.addEventListener('click', (e) => { if (e.target === modalOverlay) closeModal(); });

// ------------------ SIDEBAR NAVIGATION ------------------
document.querySelectorAll('.menu-item').forEach(item => {
    item.addEventListener('click', () => {
        document.querySelectorAll('.menu-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        renderTab(item.dataset.tab);
    });
});

function renderTab(tab) {
    switch (tab) {
        case 'products': renderProductsTab(); break;
        case 'categories': renderCategoriesTab(); break;
        case 'stockimport': renderStockImportTab(); break;
        case 'customers': renderCustomersTab(); break;
        case 'invoices': renderInvoicesTab(); break;
        case 'employees': renderEmployeesTab(); break;
        case 'assignments': renderAssignmentsTab(); break;
        case 'restock-approval': renderRestockApprovalTab(); break;
    }
}

// ============================================================
// TAB 1: KHO SAN PHAM
// ============================================================
async function renderProductsTab(keyword) {
    contentArea.innerHTML = `
        <h2>Quản Lý Kho Hàng</h2>
        <div class="panel">
            <div class="panel-header">
                <div class="search-box" style="flex:1; margin-right:16px;">
                    🔍 <input id="productSearchInput" placeholder="Tìm kiếm nhanh sản phẩm theo tên hoặc mã vạch...">
                </div>
                <button class="btn btn-green" onclick="openProductForm()">➕ Thêm Sản Phẩm</button>
            </div>
            <div id="productsTableWrap">Đang tải...</div>
        </div>`;

    document.getElementById('productSearchInput').addEventListener('input', debounce(function() {
        renderProductsTableOnly(this.value);
    }, 300));

    await loadCategoriesSuppliersCache();
    await renderProductsTableOnly(keyword);
}

async function renderProductsTableOnly(keyword) {
    const wrap = document.getElementById('productsTableWrap');
    try {
        const products = await api.get('/products' + (keyword ? '?keyword=' + encodeURIComponent(keyword) : ''));
        cache.products = products;
        if (products.length === 0) {
            wrap.innerHTML = `<div class="empty-state">Không tìm thấy sản phẩm nào.</div>`;
            return;
        }
        wrap.innerHTML = `
        <table>
            <thead><tr>
                <th>ID</th><th>Mã Vạch</th><th>Tên Sản Phẩm</th><th>Giá Bán</th><th>Tồn Kho</th><th>Đơn Vị</th><th>Hành Động</th>
            </tr></thead>
            <tbody>
                ${products.map(p => `
                <tr>
                    <td>${p.id}</td>
                    <td>${p.barcode || ''}</td>
                    <td>${p.name}</td>
                    <td class="price-blue">${formatMoney(p.price)}</td>
                    <td><span class="badge badge-green">${p.quantity}</span></td>
                    <td>${p.unit || ''}</td>
                    <td>
                        <button class="btn btn-yellow btn-sm" onclick="openProductForm(${p.id})">✏️ Sửa</button>
                        <button class="btn btn-red btn-sm" onclick="deleteProduct(${p.id})">🗑️ Xóa</button>
                    </td>
                </tr>`).join('')}
            </tbody>
        </table>`;
    } catch (err) {
        wrap.innerHTML = `<div class="empty-state">Lỗi tải dữ liệu: ${err.message}</div>`;
    }
}

function openProductForm(id) {
    const isEdit = !!id;
    const product = isEdit ? cache.products.find(p => p.id === id) : null;

    const catOptions = cache.categories.map(c =>
        `<option value="${c.id}" ${product && product.category && product.category.id === c.id ? 'selected' : ''}>${c.name}</option>`).join('');
    const supOptions = cache.suppliers.map(s =>
        `<option value="${s.id}" ${product && product.supplier && product.supplier.id === s.id ? 'selected' : ''}>${s.name}</option>`).join('');

    openModal(`
        <h3>${isEdit ? 'Sửa Sản Phẩm' : 'Thêm Sản Phẩm Mới'}</h3>
        <div class="form-group"><label>Mã vạch</label><input id="f_barcode" value="${product ? product.barcode || '' : ''}"></div>
        <div class="form-group"><label>Tên sản phẩm</label><input id="f_name" value="${product ? product.name : ''}"></div>
        <div class="form-group"><label>Danh mục</label><select id="f_category"><option value="">-- Chọn danh mục --</option>${catOptions}</select></div>
        <div class="form-group"><label>Nhà cung cấp</label><select id="f_supplier"><option value="">-- Chọn NCC --</option>${supOptions}</select></div>
        <div class="form-group"><label>Giá bán (đ)</label><input type="number" id="f_price" value="${product ? product.price : ''}"></div>
        <div class="form-group"><label>Tồn kho</label><input type="number" id="f_quantity" value="${product ? product.quantity : 0}"></div>
        <div class="form-group"><label>Đơn vị tính</label><input id="f_unit" value="${product ? product.unit || '' : ''}" placeholder="Chai, Gói, Hộp..."></div>
        <div class="modal-actions">
            <button class="btn" style="background:#e5e7eb" onclick="closeModal()">Hủy</button>
            <button class="btn btn-blue" onclick="saveProduct(${id || 'null'})">Lưu</button>
        </div>
    `);
}

async function saveProduct(id) {
    const payload = {
        barcode: document.getElementById('f_barcode').value.trim(),
        name: document.getElementById('f_name').value.trim(),
        category: document.getElementById('f_category').value ? { id: Number(document.getElementById('f_category').value) } : null,
        supplier: document.getElementById('f_supplier').value ? { id: Number(document.getElementById('f_supplier').value) } : null,
        price: Number(document.getElementById('f_price').value),
        quantity: Number(document.getElementById('f_quantity').value),
        unit: document.getElementById('f_unit').value.trim()
    };
    if (!payload.name || !payload.price) {
        showToast('Vui lòng nhập đầy đủ tên và giá bán', 'error');
        return;
    }
    try {
        if (id) await api.put('/products/' + id, payload);
        else await api.post('/products', payload);
        closeModal();
        showToast('Lưu sản phẩm thành công');
        renderProductsTableOnly();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function deleteProduct(id) {
    if (!confirm('Bạn có chắc muốn xóa sản phẩm này?')) return;
    try {
        await api.del('/products/' + id);
        showToast('Đã xóa sản phẩm');
        renderProductsTableOnly();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ============================================================
// TAB 2: DANH MUC & DOI TAC (categories + suppliers)
// ============================================================
async function loadCategoriesSuppliersCache() {
    cache.categories = await api.get('/categories');
    cache.suppliers = await api.get('/suppliers');
}

async function renderCategoriesTab() {
    await loadCategoriesSuppliersCache();
    contentArea.innerHTML = `
        <h2>Danh Mục &amp; Đối Tác</h2>
        <div class="panel">
            <div class="panel-header">
                <h3 style="margin:0">🏷️ Danh Mục Sản Phẩm</h3>
                <button class="btn btn-green" onclick="openCategoryForm()">➕ Thêm Danh Mục</button>
            </div>
            <table>
                <thead><tr><th>ID</th><th>Tên Danh Mục</th><th>Mô Tả</th><th>Hành Động</th></tr></thead>
                <tbody>
                ${cache.categories.map(c => `
                    <tr>
                        <td>${c.id}</td><td>${c.name}</td><td>${c.description || ''}</td>
                        <td>
                            <button class="btn btn-yellow btn-sm" onclick="openCategoryForm(${c.id})">✏️ Sửa</button>
                            <button class="btn btn-red btn-sm" onclick="deleteCategory(${c.id})">🗑️ Xóa</button>
                        </td>
                    </tr>`).join('') || `<tr><td colspan="4" class="empty-state">Chưa có danh mục</td></tr>`}
                </tbody>
            </table>
        </div>

        <div class="panel">
            <div class="panel-header">
                <h3 style="margin:0">🚚 Nhà Cung Cấp</h3>
                <button class="btn btn-green" onclick="openSupplierForm()">➕ Thêm Nhà Cung Cấp</button>
            </div>
            <table>
                <thead><tr><th>ID</th><th>Tên NCC</th><th>SĐT</th><th>Địa chỉ</th><th>Hành Động</th></tr></thead>
                <tbody>
                ${cache.suppliers.map(s => `
                    <tr>
                        <td>${s.id}</td><td>${s.name}</td><td>${s.phone || ''}</td><td>${s.address || ''}</td>
                        <td>
                            <button class="btn btn-yellow btn-sm" onclick="openSupplierForm(${s.id})">✏️ Sửa</button>
                            <button class="btn btn-red btn-sm" onclick="deleteSupplier(${s.id})">🗑️ Xóa</button>
                        </td>
                    </tr>`).join('') || `<tr><td colspan="5" class="empty-state">Chưa có nhà cung cấp</td></tr>`}
                </tbody>
            </table>
        </div>
    `;
}

function openCategoryForm(id) {
    const cat = id ? cache.categories.find(c => c.id === id) : null;
    openModal(`
        <h3>${id ? 'Sửa Danh Mục' : 'Thêm Danh Mục'}</h3>
        <div class="form-group"><label>Tên danh mục</label><input id="f_catname" value="${cat ? cat.name : ''}"></div>
        <div class="form-group"><label>Mô tả</label><input id="f_catdesc" value="${cat ? cat.description || '' : ''}"></div>
        <div class="modal-actions">
            <button class="btn" style="background:#e5e7eb" onclick="closeModal()">Hủy</button>
            <button class="btn btn-blue" onclick="saveCategory(${id || 'null'})">Lưu</button>
        </div>
    `);
}
async function saveCategory(id) {
    const payload = { name: document.getElementById('f_catname').value.trim(), description: document.getElementById('f_catdesc').value.trim() };
    if (!payload.name) { showToast('Vui lòng nhập tên danh mục', 'error'); return; }
    try {
        if (id) await api.put('/categories/' + id, payload); else await api.post('/categories', payload);
        closeModal(); showToast('Lưu thành công'); renderCategoriesTab();
    } catch (err) { showToast(err.message, 'error'); }
}
async function deleteCategory(id) {
    if (!confirm('Xóa danh mục này?')) return;
    try { await api.del('/categories/' + id); showToast('Đã xóa'); renderCategoriesTab(); }
    catch (err) { showToast(err.message, 'error'); }
}

function openSupplierForm(id) {
    const sup = id ? cache.suppliers.find(s => s.id === id) : null;
    openModal(`
        <h3>${id ? 'Sửa Nhà Cung Cấp' : 'Thêm Nhà Cung Cấp'}</h3>
        <div class="form-group"><label>Tên nhà cung cấp</label><input id="f_supname" value="${sup ? sup.name : ''}"></div>
        <div class="form-group"><label>Số điện thoại</label><input id="f_supphone" value="${sup ? sup.phone || '' : ''}"></div>
        <div class="form-group"><label>Địa chỉ</label><input id="f_supaddr" value="${sup ? sup.address || '' : ''}"></div>
        <div class="modal-actions">
            <button class="btn" style="background:#e5e7eb" onclick="closeModal()">Hủy</button>
            <button class="btn btn-blue" onclick="saveSupplier(${id || 'null'})">Lưu</button>
        </div>
    `);
}
async function saveSupplier(id) {
    const payload = {
        name: document.getElementById('f_supname').value.trim(),
        phone: document.getElementById('f_supphone').value.trim(),
        address: document.getElementById('f_supaddr').value.trim()
    };
    if (!payload.name) { showToast('Vui lòng nhập tên nhà cung cấp', 'error'); return; }
    try {
        if (id) await api.put('/suppliers/' + id, payload); else await api.post('/suppliers', payload);
        closeModal(); showToast('Lưu thành công'); renderCategoriesTab();
    } catch (err) { showToast(err.message, 'error'); }
}
async function deleteSupplier(id) {
    if (!confirm('Xóa nhà cung cấp này?')) return;
    try { await api.del('/suppliers/' + id); showToast('Đã xóa'); renderCategoriesTab(); }
    catch (err) { showToast(err.message, 'error'); }
}

// ============================================================
// TAB 3: NHAP HANG KHO
// ============================================================
let importCart = [];

async function renderStockImportTab() {
    await loadCategoriesSuppliersCache();
    cache.products = await api.get('/products');
    const history = await api.get('/stock-imports');

    contentArea.innerHTML = `
        <h2>Nhập Hàng Kho</h2>
        <div class="panel">
            <h3>📥 Tạo Phiếu Nhập Hàng</h3>
            <div class="filter-row" style="margin-bottom:16px;">
                <div class="form-group">
                    <label>Nhà cung cấp</label>
                    <select id="importSupplier">
                        <option value="">-- Chọn nhà cung cấp --</option>
                        ${cache.suppliers.map(s => `<option value="${s.id}">${s.name}</option>`).join('')}
                    </select>
                </div>
                <div class="form-group">
                    <label>Sản phẩm</label>
                    <select id="importProduct">
                        ${cache.products.map(p => `<option value="${p.id}">${p.name}</option>`).join('')}
                    </select>
                </div>
                <div class="form-group" style="max-width:120px;">
                    <label>Số lượng</label>
                    <input type="number" id="importQty" value="1" min="1">
                </div>
                <div class="form-group" style="max-width:160px;">
                    <label>Giá nhập (đ)</label>
                    <input type="number" id="importPrice" value="0" min="0">
                </div>
                <button class="btn btn-green" style="height:44px" onclick="addImportItem()">➕ Thêm vào phiếu</button>
            </div>
            <div id="importCartWrap"></div>
            <div class="modal-actions" style="justify-content:flex-start; margin-top:14px;">
                <button class="btn btn-blue" onclick="submitStockImport()">✅ Xác Nhận Nhập Kho</button>
                <button class="btn" style="background:#e5e7eb" onclick="importCart=[]; renderImportCart();">Xóa hết</button>
            </div>
        </div>

        <div class="panel">
            <h3>📜 Lịch Sử Nhập Hàng</h3>
            <table>
                <thead><tr><th>Mã Phiếu</th><th>Thời Gian</th><th>Nhà Cung Cấp</th><th>Tổng Tiền</th></tr></thead>
                <tbody>
                ${history.map(h => `
                    <tr>
                        <td><span class="badge badge-gray">#${h.id}</span></td>
                        <td>${formatDateTime(h.importTime)}</td>
                        <td>${h.supplier ? h.supplier.name : ''}</td>
                        <td class="text-green">${formatMoney(h.totalAmount)}</td>
                    </tr>`).join('') || `<tr><td colspan="4" class="empty-state">Chưa có phiếu nhập nào</td></tr>`}
                </tbody>
            </table>
        </div>
    `;
    renderImportCart();
}

function addImportItem() {
    const productId = Number(document.getElementById('importProduct').value);
    const qty = Number(document.getElementById('importQty').value);
    const price = Number(document.getElementById('importPrice').value);
    if (!productId || qty <= 0 || price < 0) { showToast('Vui lòng nhập số lượng / giá hợp lệ', 'error'); return; }
    const product = cache.products.find(p => p.id === productId);
    importCart.push({ productId, name: product.name, quantity: qty, price });
    renderImportCart();
}

function renderImportCart() {
    const wrap = document.getElementById('importCartWrap');
    if (!wrap) return;
    if (importCart.length === 0) {
        wrap.innerHTML = `<div class="empty-state">Chưa có sản phẩm nào trong phiếu nhập</div>`;
        return;
    }
    wrap.innerHTML = `
        <table>
            <thead><tr><th>Sản phẩm</th><th>Số lượng</th><th>Giá nhập</th><th>Thành tiền</th><th></th></tr></thead>
            <tbody>
            ${importCart.map((it, idx) => `
                <tr>
                    <td>${it.name}</td><td>${it.quantity}</td><td>${formatMoney(it.price)}</td>
                    <td>${formatMoney(it.price * it.quantity)}</td>
                    <td><button class="btn btn-red btn-sm" onclick="removeImportItem(${idx})">Xóa</button></td>
                </tr>`).join('')}
            </tbody>
        </table>`;
}
function removeImportItem(idx) { importCart.splice(idx, 1); renderImportCart(); }

async function submitStockImport() {
    if (importCart.length === 0) { showToast('Phiếu nhập chưa có sản phẩm nào', 'error'); return; }
    const supplierId = document.getElementById('importSupplier').value;
    const payload = {
        supplierId: supplierId ? Number(supplierId) : null,
        userId: currentUser.userId,
        items: importCart.map(it => ({ productId: it.productId, quantity: it.quantity, price: it.price }))
    };
    try {
        await api.post('/stock-imports', payload);
        showToast('Nhập kho thành công! Tồn kho đã được cập nhật.');
        importCart = [];
        renderStockImportTab();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ============================================================
// TAB 4: KHACH HANG
// ============================================================
async function renderCustomersTab(keyword) {
    contentArea.innerHTML = `
        <h2>Quản Lý Khách Hàng</h2>
        <div class="panel">
            <div class="panel-header">
                <div class="search-box" style="flex:1; margin-right:16px;">
                    🔍 <input id="customerSearchInput" placeholder="Tìm khách hàng theo tên hoặc số điện thoại...">
                </div>
                <button class="btn btn-green" onclick="openCustomerForm()">➕ Thêm Khách Hàng</button>
            </div>
            <div id="customersTableWrap">Đang tải...</div>
        </div>`;
    document.getElementById('customerSearchInput').addEventListener('input', debounce(function() {
        renderCustomersTableOnly(this.value);
    }, 300));
    await renderCustomersTableOnly(keyword);
}

async function renderCustomersTableOnly(keyword) {
    const wrap = document.getElementById('customersTableWrap');
    const customers = await api.get('/customers' + (keyword ? '?keyword=' + encodeURIComponent(keyword) : ''));
    cache.customers = customers;
    wrap.innerHTML = customers.length === 0 ? `<div class="empty-state">Không tìm thấy khách hàng nào.</div>` : `
        <table>
            <thead><tr><th>ID</th><th>Họ Tên</th><th>SĐT</th><th>Địa chỉ</th><th>Hành Động</th></tr></thead>
            <tbody>
            ${customers.map(c => `
                <tr>
                    <td>${c.id}</td><td>${c.name}</td><td>${c.phone || ''}</td><td>${c.address || ''}</td>
                    <td>
                        <button class="btn btn-yellow btn-sm" onclick="openCustomerForm(${c.id})">✏️ Sửa</button>
                        <button class="btn btn-red btn-sm" onclick="deleteCustomer(${c.id})">🗑️ Xóa</button>
                    </td>
                </tr>`).join('')}
            </tbody>
        </table>`;
}

function openCustomerForm(id) {
    const cust = id ? cache.customers.find(c => c.id === id) : null;
    openModal(`
        <h3>${id ? 'Sửa Khách Hàng' : 'Thêm Khách Hàng'}</h3>
        <div class="form-group"><label>Họ tên</label><input id="f_custname" value="${cust ? cust.name : ''}"></div>
        <div class="form-group"><label>Số điện thoại</label><input id="f_custphone" value="${cust ? cust.phone || '' : ''}"></div>
        <div class="form-group"><label>Địa chỉ</label><input id="f_custaddr" value="${cust ? cust.address || '' : ''}"></div>
        <div class="modal-actions">
            <button class="btn" style="background:#e5e7eb" onclick="closeModal()">Hủy</button>
            <button class="btn btn-blue" onclick="saveCustomer(${id || 'null'})">Lưu</button>
        </div>
    `);
}
async function saveCustomer(id) {
    const payload = {
        name: document.getElementById('f_custname').value.trim(),
        phone: document.getElementById('f_custphone').value.trim(),
        address: document.getElementById('f_custaddr').value.trim()
    };
    if (!payload.name) { showToast('Vui lòng nhập tên khách hàng', 'error'); return; }
    try {
        if (id) await api.put('/customers/' + id, payload); else await api.post('/customers', payload);
        closeModal(); showToast('Lưu thành công'); renderCustomersTableOnly();
    } catch (err) { showToast(err.message, 'error'); }
}
async function deleteCustomer(id) {
    if (!confirm('Xóa khách hàng này?')) return;
    try { await api.del('/customers/' + id); showToast('Đã xóa'); renderCustomersTableOnly(); }
    catch (err) { showToast(err.message, 'error'); }
}

// ============================================================
// TAB 5: LICH SU HOA DON
// ============================================================
async function renderInvoicesTab() {
    contentArea.innerHTML = `
        <h2>Lịch Sử Hóa Đơn</h2>
        <div class="panel">
            <div id="invoicesTableWrap">Đang tải...</div>
        </div>`;
    const invoices = await api.get('/sales');
    const wrap = document.getElementById('invoicesTableWrap');
    wrap.innerHTML = invoices.length === 0 ? `<div class="empty-state">Chưa có hóa đơn nào.</div>` : `
        <table>
            <thead><tr><th>Mã HĐ</th><th>Thời Gian</th><th>Khách Hàng</th><th>Nhân Viên</th><th>Tổng Tiền</th><th></th></tr></thead>
            <tbody>
            ${invoices.map(inv => `
                <tr>
                    <td><span class="badge badge-gray">#${inv.id}</span></td>
                    <td>${formatDateTime(inv.invoiceTime)}</td>
                    <td>${inv.customer ? inv.customer.name : 'Khách vãng lai'}</td>
                    <td>${inv.user ? inv.user.fullName : ''}</td>
                    <td class="text-green">${formatMoney(inv.totalAmount)}</td>
                    <td><button class="btn btn-blue btn-sm" onclick="viewInvoiceDetail(${inv.id})">Chi tiết</button></td>
                </tr>`).join('')}
            </tbody>
        </table>`;
}

async function viewInvoiceDetail(id) {
    const inv = await api.get('/sales/' + id);
    openModal(`
        <h3>Chi Tiết Hóa Đơn #${inv.id}</h3>
        <p><b>Thời gian:</b> ${formatDateTime(inv.invoiceTime)}</p>
        <p><b>Khách hàng:</b> ${inv.customer ? inv.customer.name : 'Khách vãng lai'}</p>
        <p><b>Nhân viên bán:</b> ${inv.user ? inv.user.fullName : ''}</p>
        <table style="margin-top:14px;">
            <thead><tr><th>Sản phẩm</th><th>SL</th><th>Đơn giá</th><th>Thành tiền</th></tr></thead>
            <tbody>
            ${inv.details.map(d => `
                <tr>
                    <td>${d.product.name}</td><td>${d.quantity}</td>
                    <td>${formatMoney(d.price)}</td><td>${formatMoney(d.price * d.quantity)}</td>
                </tr>`).join('')}
            </tbody>
        </table>
        <div class="cart-total" style="font-size:17px;"><span>Tổng cộng</span><span class="amount">${formatMoney(inv.totalAmount)}</span></div>
        <div class="modal-actions"><button class="btn btn-blue" onclick="closeModal()">Đóng</button></div>
    `);
}

// ============================================================
// TAB 6: QUAN LY NHAN VIEN
// ============================================================
async function renderEmployeesTab() {
    const users = await api.get('/users');
    cache.users = users;
    contentArea.innerHTML = `
        <h2>Quản Lý Nhân Viên</h2>
        <div class="panel">
            <div class="panel-header">
                <h3 style="margin:0">🧑‍💼 Danh sách tài khoản</h3>
                <button class="btn btn-green" onclick="openEmployeeForm()">➕ Thêm Nhân Viên</button>
            </div>
            <table>
                <thead><tr><th>ID</th><th>Tài khoản</th><th>Họ Tên</th><th>Vai trò</th><th>SĐT</th><th>Email</th><th>Hành Động</th></tr></thead>
                <tbody>
                ${users.map(u => `
                    <tr>
                        <td>${u.id}</td><td>${u.username}</td><td>${u.fullName || ''}</td>
                        <td><span class="badge ${u.role === 'ADMIN' ? 'badge-green' : 'badge-gray'}">${u.role === 'ADMIN' ? 'Quản Lý' : 'Nhân Viên'}</span></td>
                        <td>${u.phone || ''}</td><td>${u.email || ''}</td>
                        <td>
                            <button class="btn btn-yellow btn-sm" onclick="openEmployeeForm(${u.id})">✏️ Sửa</button>
                            <button class="btn btn-red btn-sm" onclick="deleteEmployee(${u.id})">🗑️ Xóa</button>
                        </td>
                    </tr>`).join('')}
                </tbody>
            </table>
        </div>`;
}

function openEmployeeForm(id) {
    const u = id ? cache.users.find(x => x.id === id) : null;
    openModal(`
        <h3>${id ? 'Sửa Nhân Viên' : 'Thêm Nhân Viên'}</h3>
        <div class="form-group"><label>Tài khoản đăng nhập</label><input id="f_empuser" value="${u ? u.username : ''}" ${id ? 'disabled' : ''}></div>
        <div class="form-group"><label>Mật khẩu ${id ? '(để trống nếu không đổi)' : ''}</label><input type="password" id="f_emppass"></div>
        <div class="form-group"><label>Họ tên</label><input id="f_empname" value="${u ? u.fullName || '' : ''}"></div>
        <div class="form-group"><label>Vai trò</label>
            <select id="f_emprole">
                <option value="STAFF" ${u && u.role === 'STAFF' ? 'selected' : ''}>Nhân Viên</option>
                <option value="ADMIN" ${u && u.role === 'ADMIN' ? 'selected' : ''}>Quản Lý</option>
            </select>
        </div>
        <div class="form-group"><label>Số điện thoại</label><input id="f_empphone" value="${u ? u.phone || '' : ''}"></div>
        <div class="form-group"><label>Email</label><input id="f_empemail" value="${u ? u.email || '' : ''}"></div>
        <div class="modal-actions">
            <button class="btn" style="background:#e5e7eb" onclick="closeModal()">Hủy</button>
            <button class="btn btn-blue" onclick="saveEmployee(${id || 'null'})">Lưu</button>
        </div>
    `);
}
async function saveEmployee(id) {
    const payload = {
        username: document.getElementById('f_empuser').value.trim(),
        password: document.getElementById('f_emppass').value,
        fullName: document.getElementById('f_empname').value.trim(),
        role: document.getElementById('f_emprole').value,
        phone: document.getElementById('f_empphone').value.trim(),
        email: document.getElementById('f_empemail').value.trim()
    };
    if (!payload.username || (!id && !payload.password)) {
        showToast('Vui lòng nhập đủ tài khoản và mật khẩu', 'error'); return;
    }
    try {
        if (id) await api.put('/users/' + id, payload); else await api.post('/users', payload);
        closeModal(); showToast('Lưu thành công'); renderEmployeesTab();
    } catch (err) { showToast(err.message, 'error'); }
}
async function deleteEmployee(id) {
    if (id === currentUser.userId) { showToast('Không thể tự xóa tài khoản đang đăng nhập', 'error'); return; }
    if (!confirm('Xóa nhân viên này?')) return;
    try { await api.del('/users/' + id); showToast('Đã xóa'); renderEmployeesTab(); }
    catch (err) { showToast(err.message, 'error'); }
}

// ============================================================
// TAB 7: PHAN CONG NHAN VIEN QUAN LY DANH MUC
// ============================================================
async function renderAssignmentsTab() {
    await loadCategoriesSuppliersCache();
    const users = await api.get('/users');
    const staffUsers = users.filter(u => u.role === 'STAFF');
    cache.users = users;

    const assignments = await api.get('/assignments');

    contentArea.innerHTML = `
        <h2>Phân Công Nhân Viên Quản Lý Danh Mục</h2>
        <div class="panel">
            <h3>➕ Thêm phân công mới</h3>
            <div class="filter-row">
                <div class="form-group">
                    <label>Nhân viên</label>
                    <select id="assignUser">
                        ${staffUsers.map(u => `<option value="${u.id}">${u.fullName || u.username}</option>`).join('') || `<option value="">Chưa có nhân viên nào</option>`}
                    </select>
                </div>
                <div class="form-group">
                    <label>Danh mục sản phẩm</label>
                    <select id="assignCategory">
                        ${cache.categories.map(c => `<option value="${c.id}">${c.name}</option>`).join('') || `<option value="">Chưa có danh mục nào</option>`}
                    </select>
                </div>
                <button class="btn btn-green" style="height:44px" onclick="createAssignment()">✅ Phân công</button>
            </div>
        </div>

        <div class="panel">
            <h3>🗂️ Danh sách phân công hiện tại</h3>
            <table>
                <thead><tr><th>Nhân viên</th><th>Danh mục quản lý</th><th>Ngày phân công</th><th>Hành Động</th></tr></thead>
                <tbody>
                ${assignments.map(a => `
                    <tr>
                        <td>${a.user.fullName || a.user.username}</td>
                        <td><span class="badge badge-gray">${a.category.name}</span></td>
                        <td>${formatDateTime(a.assignedAt)}</td>
                        <td><button class="btn btn-red btn-sm" onclick="removeAssignment(${a.id})">🗑️ Hủy phân công</button></td>
                    </tr>`).join('') || `<tr><td colspan="4" class="empty-state">Chưa có phân công nào</td></tr>`}
                </tbody>
            </table>
        </div>`;
}

async function createAssignment() {
    const userId = Number(document.getElementById('assignUser').value);
    const categoryId = Number(document.getElementById('assignCategory').value);
    if (!userId || !categoryId) { showToast('Vui lòng chọn nhân viên và danh mục', 'error'); return; }
    try {
        await api.post('/assignments', { userId, categoryId });
        showToast('Phân công thành công');
        renderAssignmentsTab();
    } catch (err) { showToast(err.message, 'error'); }
}

async function removeAssignment(id) {
    if (!confirm('Hủy phân công này?')) return;
    try { await api.del('/assignments/' + id); showToast('Đã hủy phân công'); renderAssignmentsTab(); }
    catch (err) { showToast(err.message, 'error'); }
}

// ============================================================
// TAB 8: DUYET DE XUAT NHAP HANG TU NHAN VIEN
// ============================================================
async function renderRestockApprovalTab() {
    contentArea.innerHTML = `
        <h2>Duyệt Đề Xuất Nhập Hàng</h2>
        <div class="panel" id="restockApprovalWrap">Đang tải...</div>`;

    const requests = await api.get('/restock-requests');
    const wrap = document.getElementById('restockApprovalWrap');

    const statusBadge = (status) => {
        if (status === 'APPROVED') return `<span class="badge badge-green">Đã duyệt</span>`;
        if (status === 'REJECTED') return `<span class="badge" style="background:#dc2626;">Từ chối</span>`;
        return `<span class="badge" style="background:#eab308;color:#1a1a1a;">Đang chờ duyệt</span>`;
    };

    wrap.innerHTML = requests.length === 0 ? `<div class="empty-state">Chưa có đề xuất nhập hàng nào từ nhân viên.</div>` : `
        <table>
            <thead><tr><th>Nhân viên đề xuất</th><th>Sản phẩm</th><th>Số lượng</th><th>Ghi chú</th><th>Ngày gửi</th><th>Trạng thái</th><th>Hành Động</th></tr></thead>
            <tbody>
            ${requests.map(r => `
                <tr>
                    <td>${r.proposedBy ? (r.proposedBy.fullName || r.proposedBy.username) : ''}</td>
                    <td>${r.product.name}</td>
                    <td><span class="badge badge-green">${r.quantity}</span></td>
                    <td>${r.note || ''}</td>
                    <td>${formatDateTime(r.createdAt)}</td>
                    <td>${statusBadge(r.status)}</td>
                    <td>
                        ${r.status === 'PENDING' ? `
                            <button class="btn btn-green btn-sm" onclick="approveRestock(${r.id})">✅ Duyệt</button>
                            <button class="btn btn-red btn-sm" onclick="rejectRestock(${r.id})">❌ Từ chối</button>
                        ` : (r.processedBy ? `Bởi: ${r.processedBy.fullName || r.processedBy.username}` : '')}
                    </td>
                </tr>`).join('')}
            </tbody>
        </table>`;
}

async function approveRestock(id) {
    if (!confirm('Duyệt đề xuất này? Hệ thống sẽ tự động tạo phiếu nhập kho và cộng tồn kho tương ứng.')) return;
    try {
        await api.put(`/restock-requests/${id}/approve?adminUserId=${currentUser.userId}`);
        showToast('Đã duyệt đề xuất, tồn kho đã được cập nhật');
        renderRestockApprovalTab();
    } catch (err) { showToast(err.message, 'error'); }
}

async function rejectRestock(id) {
    if (!confirm('Từ chối đề xuất này?')) return;
    try {
        await api.put(`/restock-requests/${id}/reject?adminUserId=${currentUser.userId}`);
        showToast('Đã từ chối đề xuất');
        renderRestockApprovalTab();
    } catch (err) { showToast(err.message, 'error'); }
}

// ------------------ UTIL ------------------
function debounce(fn, delay) {
    let timer;
    return function(...args) {
        clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), delay);
    };
}

// ------------------ INIT ------------------
if (currentUser) renderProductsTab();

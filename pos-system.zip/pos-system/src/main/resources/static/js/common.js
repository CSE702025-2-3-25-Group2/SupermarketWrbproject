const API_BASE = '/api';

// ============ FORMAT ============
function formatMoney(value) {
    if (value === null || value === undefined) return '0 đ';
    return Number(value).toLocaleString('vi-VN') + ' đ';
}

function formatDateTime(iso) {
    const d = new Date(iso);
    return d.toLocaleString('vi-VN');
}

// ============ TOAST ============
function showToast(message, type = 'success') {
    let toast = document.getElementById('global-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'global-toast';
        toast.className = 'toast';
        document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.className = 'toast show ' + type;
    setTimeout(() => toast.classList.remove('show'), 2800);
}

// ============ AUTH ============
function getCurrentUser() {
    const raw = sessionStorage.getItem('pos_user');
    return raw ? JSON.parse(raw) : null;
}

function requireLogin() {
    const user = getCurrentUser();
    if (!user) {
        window.location.href = '/login.html';
        return null;
    }
    return user;
}

function requireAdmin() {
    const user = requireLogin();
    if (user && user.role !== 'ADMIN') {
        showToast('Chỉ Quản Trị Viên mới có quyền truy cập trang này', 'error');
        setTimeout(() => window.location.href = '/pos.html', 1200);
        return null;
    }
    return user;
}

function logout() {
    sessionStorage.removeItem('pos_user');
    window.location.href = '/login.html';
}

// ============ API HELPER ============
async function apiRequest(method, url, body) {
    const options = {
        method,
        headers: { 'Content-Type': 'application/json' }
    };
    if (body !== undefined) options.body = JSON.stringify(body);

    const res = await fetch(API_BASE + url, options);
    let data = null;
    try { data = await res.json(); } catch (e) { /* no content */ }

    if (!res.ok) {
        const msg = (data && data.message) ? data.message : 'Đã có lỗi xảy ra';
        throw new Error(msg);
    }
    return data;
}

const api = {
    get: (url) => apiRequest('GET', url),
    post: (url, body) => apiRequest('POST', url, body),
    put: (url, body) => apiRequest('PUT', url, body),
    del: (url) => apiRequest('DELETE', url)
};

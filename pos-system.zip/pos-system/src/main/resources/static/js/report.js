// ============================================================
// REPORT.JS - Logic trang bao cao doanh thu / thong ke
// ============================================================

let reportUser = requireLogin();

function renderTopActions() {
    const wrap = document.getElementById('topActions');
    let html = '';
    if (reportUser.role === 'ADMIN') {
        html += `<button class="btn-outline" onclick="location.href='/admin.html'">📦 Quản lý kho</button>`;
    }
    html += `<button class="btn-solid-blue" onclick="location.href='/pos.html'">🛒 Vào quầy bán</button>`;
    if (reportUser.role === 'ADMIN') {
        html += `<button class="btn-outline" onclick="location.href='/admin.html'">👤 Quản trị viên</button>`;
    }
    wrap.innerHTML = html;
}

function todayStr() {
    const d = new Date();
    return d.toISOString().slice(0, 10);
}

function initDefaultDates() {
    document.getElementById('fromDate').value = todayStr();
    document.getElementById('toDate').value = todayStr();
}

async function loadReport() {
    const from = document.getElementById('fromDate').value;
    const to = document.getElementById('toDate').value;
    const groupBy = document.getElementById('groupBy').value;

    if (!from || !to) { showToast('Vui lòng chọn khoảng thời gian', 'error'); return; }

    try {
        const revenue = await api.get(`/reports/revenue?from=${from}&to=${to}`);
        document.getElementById('statTotalRevenue').textContent = formatMoney(revenue.totalRevenue);
        document.getElementById('statInvoiceCount').textContent = revenue.invoiceCount;
        document.getElementById('statAvgOrder').textContent = formatMoney(revenue.averageOrderValue);

        const invoiceWrap = document.getElementById('invoiceListWrap');
        invoiceWrap.innerHTML = revenue.invoices.length === 0
            ? `<div class="empty-state">Không có hóa đơn nào trong khoảng thời gian này.</div>`
            : `<table>
                <thead><tr><th>Mã Hóa Đơn</th><th>Thời Gian Bán</th><th>Khách Hàng</th><th style="text-align:right">Tổng Tiền Hóa Đơn</th></tr></thead>
                <tbody>
                ${revenue.invoices.map(inv => `
                    <tr>
                        <td><span class="badge badge-gray">#${inv.id}</span></td>
                        <td>${formatDateTime(inv.invoiceTime)}</td>
                        <td>${inv.customer ? inv.customer.name : 'Khách vãng lai'}</td>
                        <td class="text-green" style="text-align:right">${formatMoney(inv.totalAmount)}</td>
                    </tr>`).join('')}
                </tbody>
            </table>`;

        // San pham ban chay
        const best = await api.get(`/reports/best-selling?from=${from}&to=${to}&limit=10`);
        const bestWrap = document.getElementById('bestSellingWrap');
        bestWrap.innerHTML = best.length === 0
            ? `<div class="empty-state">Chưa có dữ liệu bán hàng trong khoảng thời gian này.</div>`
            : `<table>
                <thead><tr><th>#</th><th>Sản phẩm</th><th>Số lượng đã bán</th><th style="text-align:right">Doanh thu</th></tr></thead>
                <tbody>
                ${best.map((b, idx) => `
                    <tr>
                        <td>${idx + 1}</td><td>${b.productName}</td>
                        <td><span class="badge badge-green">${b.totalQuantitySold}</span></td>
                        <td class="text-green" style="text-align:right">${formatMoney(b.totalRevenue)}</td>
                    </tr>`).join('')}
                </tbody>
            </table>`;

        // Bieu do doanh thu theo ngay/thang/nam (dang bang don gian)
        void groupBy; // du lieu bieu do co the mo rong sau (chart.js) neu can
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function loadInventory() {
    const wrap = document.getElementById('inventoryWrap');
    try {
        const products = await api.get('/reports/inventory');
        wrap.innerHTML = `
            <table>
                <thead><tr><th>Sản phẩm</th><th>Tồn kho</th><th>Đơn vị</th><th>Giá bán</th><th>Trạng thái</th></tr></thead>
                <tbody>
                ${products.map(p => `
                    <tr>
                        <td>${p.name}</td>
                        <td><span class="badge ${p.quantity <= 10 ? 'badge-gray' : 'badge-green'}">${p.quantity}</span></td>
                        <td>${p.unit || ''}</td>
                        <td class="price-blue">${formatMoney(p.price)}</td>
                        <td>${p.quantity <= 10 ? '⚠️ Sắp hết hàng' : '✅ Còn hàng'}</td>
                    </tr>`).join('')}
                </tbody>
            </table>`;
    } catch (err) {
        wrap.innerHTML = `<div class="empty-state">Lỗi tải tồn kho: ${err.message}</div>`;
    }
}

// ------------------ INIT ------------------
if (reportUser) {
    renderTopActions();
    initDefaultDates();
    loadReport();
    loadInventory();
}

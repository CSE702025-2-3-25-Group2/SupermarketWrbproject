// ============================================================
// POS.JS - Logic man hinh quay ban hang
// ============================================================

let posUser = requireLogin();
let allProducts = [];
let cart = []; // { productId, name, price, quantity, stock }

// ------------------ TOPBAR THEO VAI TRO ------------------
function renderTopActions() {
    const wrap = document.getElementById('topActions');
    let html = '';
    if (posUser.role === 'ADMIN') {
        html += `<button class="btn-outline" onclick="location.href='/admin.html'">📦 Quản lý kho</button>`;
        html += `<button class="btn-solid-blue" onclick="location.href='/report.html'">📈 Báo cáo doanh thu</button>`;
    } else {
        html += `<button class="btn-outline" onclick="location.href='/staff.html'">🧑‍💼 Khu vực nhân viên</button>`;
    }
    html += `<button class="btn-solid-red" onclick="logout()">⏻ Đăng xuất (${posUser.fullName || posUser.username})</button>`;
    wrap.innerHTML = html;
}

// ------------------ TAI SAN PHAM ------------------
async function loadProducts(keyword) {
    const grid = document.getElementById('productGrid');
    try {
        allProducts = await api.get('/products' + (keyword ? '?keyword=' + encodeURIComponent(keyword) : ''));
        if (allProducts.length === 0) {
            grid.innerHTML = `<div class="empty-state">Không tìm thấy sản phẩm nào.</div>`;
            return;
        }
        grid.innerHTML = allProducts.map(p => `
            <div class="product-card" onclick="addToCart(${p.id})">
                <div class="product-icon">📦</div>
                <div class="pname">${p.name}</div>
                <div class="pprice">${formatMoney(p.price)}</div>
                <div class="pstock">Tồn: ${p.quantity} ${p.unit || ''}</div>
            </div>`).join('');
    } catch (err) {
        grid.innerHTML = `<div class="empty-state">Lỗi tải sản phẩm: ${err.message}</div>`;
    }
}

async function loadCustomers() {
    const customers = await api.get('/customers');
    const select = document.getElementById('posCustomer');
    customers.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.id;
        opt.textContent = c.name + (c.phone ? ' - ' + c.phone : '');
        select.appendChild(opt);
    });
}

// ------------------ GIO HANG ------------------
function addToCart(productId) {
    const product = allProducts.find(p => p.id === productId);
    if (!product) return;
    if (product.quantity <= 0) { showToast('Sản phẩm đã hết hàng', 'error'); return; }

    const existing = cart.find(c => c.productId === productId);
    if (existing) {
        if (existing.quantity + 1 > product.quantity) { showToast('Vượt quá số lượng tồn kho', 'error'); return; }
        existing.quantity++;
    } else {
        cart.push({ productId, name: product.name, price: product.price, quantity: 1, stock: product.quantity });
    }
    renderCart();
}

function changeQty(productId, delta) {
    const item = cart.find(c => c.productId === productId);
    if (!item) return;
    const newQty = item.quantity + delta;
    if (newQty <= 0) {
        cart = cart.filter(c => c.productId !== productId);
    } else if (newQty > item.stock) {
        showToast('Vượt quá số lượng tồn kho', 'error');
        return;
    } else {
        item.quantity = newQty;
    }
    renderCart();
}

function renderCart() {
    const wrap = document.getElementById('cartItems');
    const totalEl = document.getElementById('cartTotal');

    if (cart.length === 0) {
        wrap.innerHTML = `<div class="empty-state">Chưa có sản phẩm nào trong giỏ hàng</div>`;
        totalEl.textContent = formatMoney(0);
        return;
    }

    wrap.innerHTML = cart.map(item => `
        <div class="cart-row">
            <div>
                <div class="cname">${item.name}</div>
                <div style="font-size:12px;color:#6b7280;">${formatMoney(item.price)} / sp</div>
            </div>
            <div class="cqty">
                <button onclick="changeQty(${item.productId}, -1)">−</button>
                <span>${item.quantity}</span>
                <button onclick="changeQty(${item.productId}, 1)">+</button>
            </div>
        </div>`).join('');

    const total = cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
    totalEl.textContent = formatMoney(total);
}

// ------------------ THANH TOAN ------------------
async function checkout() {
    if (cart.length === 0) { showToast('Giỏ hàng đang trống', 'error'); return; }

    const customerId = document.getElementById('posCustomer').value;
    const payload = {
        customerId: customerId ? Number(customerId) : null,
        userId: posUser.userId,
        items: cart.map(i => ({ productId: i.productId, quantity: i.quantity }))
    };

    try {
        const invoice = await api.post('/sales', payload);
        showToast('Thanh toán thành công! Hóa đơn #' + invoice.id);
        cart = [];
        renderCart();
        document.getElementById('posCustomer').value = '';
        loadProducts(); // cap nhat lai ton kho hien thi
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// ------------------ TIM KIEM ------------------
document.getElementById('posSearchInput').addEventListener('input', debounce(function() {
    loadProducts(this.value);
}, 300));

function debounce(fn, delay) {
    let timer;
    return function(...args) {
        clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), delay);
    };
}

// ------------------ INIT ------------------
if (posUser) {
    renderTopActions();
    loadProducts();
    loadCustomers();
}

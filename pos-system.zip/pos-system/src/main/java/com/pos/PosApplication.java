package com.pos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PosApplication {
    public static void main(String[] args) {
        SpringApplication.run(PosApplication.class, args);
        System.out.println("========================================");
        System.out.println(" HE THONG SIEU THI POS DA KHOI DONG!");
        System.out.println(" Trang dang nhap: http://localhost:8080/login.html");
        System.out.println("========================================");
    }
}

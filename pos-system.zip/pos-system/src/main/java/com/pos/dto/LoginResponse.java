package com.pos.dto;

import com.pos.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LoginResponse {
    private boolean success;
    private String message;
    private Long userId;
    private String username;
    private String fullName;
    private User.Role role;

    public static LoginResponse fail(String message) {
        return new LoginResponse(false, message, null, null, null, null);
    }

    public static LoginResponse ok(User u) {
        return new LoginResponse(true, "Dang nhap thanh cong", u.getId(), u.getUsername(), u.getFullName(), u.getRole());
    }
}

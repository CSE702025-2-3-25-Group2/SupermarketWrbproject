package com.pos.dto;

import lombok.Data;

@Data
public class RestockRequestDTO {
    private Long productId;
    private Long userId;   // nhan vien de xuat
    private Integer quantity;
    private String note;
}

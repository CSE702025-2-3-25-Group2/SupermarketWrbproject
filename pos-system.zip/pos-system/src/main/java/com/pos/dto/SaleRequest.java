package com.pos.dto;

import lombok.Data;

import java.util.List;

@Data
public class SaleRequest {
    private Long customerId;   // co the null -> khach vang lai
    private Long userId;       // nhan vien ban hang
    private List<SaleItem> items;

    @Data
    public static class SaleItem {
        private Long productId;
        private Integer quantity;
    }
}

package com.pos.dto;

import com.pos.entity.Invoice;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
public class RevenueReportResponse {
    private BigDecimal totalRevenue;
    private Long invoiceCount;
    private BigDecimal averageOrderValue;
    private List<Invoice> invoices;
}

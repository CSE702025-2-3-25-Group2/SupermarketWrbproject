package com.pos.dto;

import lombok.Data;

import java.util.List;

@Data
public class StockImportRequest {
    private Long supplierId;
    private Long userId;
    private List<ImportItem> items;

    @Data
    public static class ImportItem {
        private Long productId;
        private Integer quantity;
        private java.math.BigDecimal price;
    }
}

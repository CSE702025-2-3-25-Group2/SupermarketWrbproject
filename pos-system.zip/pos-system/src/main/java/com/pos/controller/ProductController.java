package com.pos.controller;

import com.pos.entity.Product;
import com.pos.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping
    public List<Product> getAll(@RequestParam(required = false) String keyword) {
        if (keyword != null) return productService.search(keyword);
        return productService.getAll();
    }

    @GetMapping("/{id}")
    public Product getById(@PathVariable Long id) {
        return productService.getById(id);
    }

    @GetMapping("/low-stock")
    public List<Product> lowStock(@RequestParam(defaultValue = "10") int threshold) {
        return productService.lowStock(threshold);
    }

    // San pham thuoc cac danh muc duoc phan cong cho nhan vien (vd: ?categoryIds=1,3)
    @GetMapping("/by-categories")
    public List<Product> getByCategories(@RequestParam List<Long> categoryIds) {
        return productService.getByCategoryIds(categoryIds);
    }

    @PostMapping
    public Product create(@RequestBody Product product) {
        return productService.create(product);
    }

    @PutMapping("/{id}")
    public Product update(@PathVariable Long id, @RequestBody Product product) {
        return productService.update(id, product);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        productService.delete(id);
    }
}

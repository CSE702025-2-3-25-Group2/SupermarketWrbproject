package com.pos.controller;

import com.pos.dto.RestockRequestDTO;
import com.pos.entity.RestockRequest;
import com.pos.service.RestockRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/restock-requests")
public class RestockRequestController {

    @Autowired
    private RestockRequestService restockRequestService;

    // Nhan vien tao de xuat nhap hang
    @PostMapping
    public RestockRequest create(@RequestBody RestockRequestDTO dto) {
        return restockRequestService.create(dto);
    }

    // Admin xem toan bo de xuat
    @GetMapping
    public List<RestockRequest> getAll() {
        return restockRequestService.getAll();
    }

    // Admin xem cac de xuat dang cho duyet
    @GetMapping("/pending")
    public List<RestockRequest> getPending() {
        return restockRequestService.getPending();
    }

    // Nhan vien xem lai cac de xuat cua chinh minh
    @GetMapping("/user/{userId}")
    public List<RestockRequest> getByUser(@PathVariable Long userId) {
        return restockRequestService.getByUser(userId);
    }

    // Admin duyet de xuat -> tu dong tao phieu nhap kho va cong ton kho
    @PutMapping("/{id}/approve")
    public RestockRequest approve(@PathVariable Long id, @RequestParam Long adminUserId) {
        return restockRequestService.approve(id, adminUserId);
    }

    // Admin tu choi de xuat
    @PutMapping("/{id}/reject")
    public RestockRequest reject(@PathVariable Long id, @RequestParam Long adminUserId) {
        return restockRequestService.reject(id, adminUserId);
    }
}

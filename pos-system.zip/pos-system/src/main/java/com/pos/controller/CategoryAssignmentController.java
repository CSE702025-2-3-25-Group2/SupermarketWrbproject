package com.pos.controller;

import com.pos.entity.Category;
import com.pos.entity.CategoryAssignment;
import com.pos.service.CategoryAssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/assignments")
public class CategoryAssignmentController {

    @Autowired
    private CategoryAssignmentService assignmentService;

    // Toan bo phan cong (danh cho Admin xem tong quan)
    @GetMapping
    public List<CategoryAssignment> getAll() {
        return assignmentService.getAll();
    }

    // Danh sach danh muc ma 1 nhan vien duoc phan cong quan ly
    @GetMapping("/user/{userId}")
    public List<Category> getCategoriesOfUser(@PathVariable Long userId) {
        return assignmentService.getCategoriesOfUser(userId);
    }

    // Phan cong nhan vien quan ly 1 danh muc: body { "userId": 2, "categoryId": 1 }
    @PostMapping
    public CategoryAssignment assign(@RequestBody Map<String, Long> body) {
        return assignmentService.assign(body.get("userId"), body.get("categoryId"));
    }

    @DeleteMapping("/{id}")
    public void unassign(@PathVariable Long id) {
        assignmentService.unassign(id);
    }
}

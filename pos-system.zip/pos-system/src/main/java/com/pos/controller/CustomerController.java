package com.pos.controller;

import com.pos.entity.Customer;
import com.pos.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @GetMapping
    public List<Customer> getAll(@RequestParam(required = false) String keyword) {
        if (keyword != null) return customerService.search(keyword);
        return customerService.getAll();
    }

    @PostMapping
    public Customer create(@RequestBody Customer c) { return customerService.create(c); }

    @PutMapping("/{id}")
    public Customer update(@PathVariable Long id, @RequestBody Customer c) { return customerService.update(id, c); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { customerService.delete(id); }
}

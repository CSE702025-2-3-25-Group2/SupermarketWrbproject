package com.pos.controller;

import com.pos.entity.Supplier;
import com.pos.service.SupplierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/suppliers")
public class SupplierController {
    @Autowired
    private SupplierService supplierService;

    @GetMapping
    public List<Supplier> getAll() { return supplierService.getAll(); }

    @PostMapping
    public Supplier create(@RequestBody Supplier s) { return supplierService.create(s); }

    @PutMapping("/{id}")
    public Supplier update(@PathVariable Long id, @RequestBody Supplier s) { return supplierService.update(id, s); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { supplierService.delete(id); }
}

package com.pos.controller;

import com.pos.dto.StockImportRequest;
import com.pos.entity.StockImport;
import com.pos.service.StockImportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/stock-imports")
public class StockImportController {

    @Autowired
    private StockImportService stockImportService;

    // Tao phieu nhap hang - tu dong cong ton kho
    @PostMapping
    public StockImport createImport(@RequestBody StockImportRequest request) {
        return stockImportService.createImport(request);
    }

    @GetMapping
    public List<StockImport> getAll() {
        return stockImportService.getAll();
    }

    @GetMapping("/{id}")
    public StockImport getById(@PathVariable Long id) {
        return stockImportService.getById(id);
    }
}

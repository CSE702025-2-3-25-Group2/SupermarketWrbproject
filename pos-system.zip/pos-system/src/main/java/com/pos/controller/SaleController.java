package com.pos.controller;

import com.pos.dto.SaleRequest;
import com.pos.entity.Invoice;
import com.pos.service.SaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/sales")
public class SaleController {

    @Autowired
    private SaleService saleService;

    // Tao hoa don ban hang - tu dong tru ton kho
    @PostMapping
    public Invoice createSale(@RequestBody SaleRequest request) {
        return saleService.createSale(request);
    }

    @GetMapping
    public List<Invoice> getAll() {
        return saleService.getAll();
    }

    @GetMapping("/{id}")
    public Invoice getById(@PathVariable Long id) {
        return saleService.getById(id);
    }

    @GetMapping("/search")
    public List<Invoice> search(@RequestParam String from, @RequestParam String to) {
        LocalDateTime fromDt = LocalDateTime.parse(from);
        LocalDateTime toDt = LocalDateTime.parse(to);
        return saleService.getByDateRange(fromDt, toDt);
    }
}

package com.pos.controller;

import com.pos.entity.Category;
import com.pos.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public List<Category> getAll() { return categoryService.getAll(); }

    @PostMapping
    public Category create(@RequestBody Category c) { return categoryService.create(c); }

    @PutMapping("/{id}")
    public Category update(@PathVariable Long id, @RequestBody Category c) { return categoryService.update(id, c); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { categoryService.delete(id); }
}

package com.pos.controller;

import com.pos.entity.User;
import com.pos.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping
    public List<User> getAll() { return userService.getAll(); }

    @GetMapping("/{id}")
    public User getById(@PathVariable Long id) { return userService.getById(id); }

    @PostMapping
    public User create(@RequestBody User u) { return userService.create(u); }

    @PutMapping("/{id}")
    public User update(@PathVariable Long id, @RequestBody User u) { return userService.update(id, u); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { userService.delete(id); }
}

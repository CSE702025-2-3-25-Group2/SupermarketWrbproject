package com.pos.controller;

import com.pos.dto.BestSellingProductResponse;
import com.pos.dto.RevenueReportResponse;
import com.pos.entity.Product;
import com.pos.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    // Bao cao doanh thu theo khoang ngay (yyyy-MM-dd)
    @GetMapping("/revenue")
    public RevenueReportResponse getRevenue(@RequestParam String from, @RequestParam String to) {
        LocalDateTime fromDt = LocalDate.parse(from).atStartOfDay();
        LocalDateTime toDt = LocalDate.parse(to).atTime(LocalTime.MAX);
        return reportService.getRevenueReport(fromDt, toDt);
    }

    // Doanh thu theo ngay/thang/nam - dung cho bieu do. groupBy = day|month|year
    @GetMapping("/revenue/chart")
    public Map<String, BigDecimal> getRevenueChart(@RequestParam String from, @RequestParam String to,
                                                     @RequestParam(defaultValue = "day") String groupBy) {
        LocalDateTime fromDt = LocalDate.parse(from).atStartOfDay();
        LocalDateTime toDt = LocalDate.parse(to).atTime(LocalTime.MAX);
        return switch (groupBy) {
            case "month" -> reportService.getRevenueGroupedByMonth(fromDt, toDt);
            case "year" -> reportService.getRevenueGroupedByYear(fromDt, toDt);
            default -> reportService.getRevenueGroupedByDay(fromDt, toDt);
        };
    }

    // San pham ban chay nhat
    @GetMapping("/best-selling")
    public List<BestSellingProductResponse> getBestSelling(@RequestParam String from, @RequestParam String to,
                                                             @RequestParam(defaultValue = "10") int limit) {
        LocalDateTime fromDt = LocalDate.parse(from).atStartOfDay();
        LocalDateTime toDt = LocalDate.parse(to).atTime(LocalTime.MAX);
        return reportService.getBestSellingProducts(fromDt, toDt, limit);
    }

    // Bao cao ton kho toan bo san pham
    @GetMapping("/inventory")
    public List<Product> getInventory() {
        return reportService.getInventoryReport();
    }

    // San pham sap het hang
    @GetMapping("/low-stock")
    public List<Product> getLowStock(@RequestParam(defaultValue = "10") int threshold) {
        return reportService.getLowStockProducts(threshold);
    }

    // Bao cao doanh thu danh cho NHAN VIEN, chi tinh tren cac danh muc duoc phan cong.
    // vd: /api/reports/staff-revenue?categoryIds=1,3&from=2026-07-01&to=2026-07-10&groupBy=week
    @GetMapping("/staff-revenue")
    public java.util.Map<String, java.math.BigDecimal> getStaffRevenue(@RequestParam List<Long> categoryIds,
                                                                          @RequestParam String from,
                                                                          @RequestParam String to,
                                                                          @RequestParam(defaultValue = "day") String groupBy) {
        LocalDateTime fromDt = LocalDate.parse(from).atStartOfDay();
        LocalDateTime toDt = LocalDate.parse(to).atTime(LocalTime.MAX);
        return reportService.getStaffRevenueGrouped(categoryIds, fromDt, toDt, groupBy);
    }
}

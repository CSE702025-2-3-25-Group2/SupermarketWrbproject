package com.pos.service;

import com.pos.entity.Supplier;
import com.pos.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierService {
    @Autowired
    private SupplierRepository supplierRepository;

    public List<Supplier> getAll() { return supplierRepository.findAll(); }
    public Supplier create(Supplier s) { return supplierRepository.save(s); }
    public Supplier update(Long id, Supplier payload) {
        Supplier s = supplierRepository.findById(id).orElseThrow(() -> new RuntimeException("Khong tim thay nha cung cap"));
        s.setName(payload.getName());
        s.setPhone(payload.getPhone());
        s.setAddress(payload.getAddress());
        return supplierRepository.save(s);
    }
    public void delete(Long id) { supplierRepository.deleteById(id); }
}

package com.pos.service;

import com.pos.entity.Category;
import com.pos.entity.CategoryAssignment;
import com.pos.entity.User;
import com.pos.repository.CategoryAssignmentRepository;
import com.pos.repository.CategoryRepository;
import com.pos.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CategoryAssignmentService {

    @Autowired
    private CategoryAssignmentRepository assignmentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    public List<CategoryAssignment> getAll() {
        return assignmentRepository.findAll();
    }

    // Danh sach danh muc ma 1 nhan vien dang duoc phan cong quan ly
    public List<Category> getCategoriesOfUser(Long userId) {
        return assignmentRepository.findByUserId(userId).stream()
                .map(CategoryAssignment::getCategory)
                .collect(Collectors.toList());
    }

    public CategoryAssignment assign(Long userId, Long categoryId) {
        if (assignmentRepository.findByUserIdAndCategoryId(userId, categoryId).isPresent()) {
            throw new RuntimeException("Nhân viên này đã được phân công quản lý danh mục này rồi");
        }
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("Không tìm thấy nhân viên"));
        Category category = categoryRepository.findById(categoryId).orElseThrow(() -> new RuntimeException("Không tìm thấy danh mục"));

        CategoryAssignment assignment = new CategoryAssignment();
        assignment.setUser(user);
        assignment.setCategory(category);
        return assignmentRepository.save(assignment);
    }

    public void unassign(Long assignmentId) {
        assignmentRepository.deleteById(assignmentId);
    }
}

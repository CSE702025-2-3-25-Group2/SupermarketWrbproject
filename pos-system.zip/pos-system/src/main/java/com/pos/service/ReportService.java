package com.pos.service;

import com.pos.dto.BestSellingProductResponse;
import com.pos.dto.RevenueReportResponse;
import com.pos.entity.Invoice;
import com.pos.entity.InvoiceDetail;
import com.pos.entity.Product;
import com.pos.repository.InvoiceDetailRepository;
import com.pos.repository.InvoiceRepository;
import com.pos.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ReportService {

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private InvoiceDetailRepository invoiceDetailRepository;

    @Autowired
    private ProductRepository productRepository;

    /**
     * Bao cao doanh thu theo khoang thoi gian tuy chon (co the dung cho
     * thong ke theo ngay / thang / nam bang cach truyen from-to phu hop).
     */
    public RevenueReportResponse getRevenueReport(LocalDateTime from, LocalDateTime to) {
        List<Invoice> invoices = invoiceRepository.findByInvoiceTimeBetweenOrderByInvoiceTimeDesc(from, to);

        BigDecimal total = invoices.stream()
                .map(Invoice::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        long count = invoices.size();
        BigDecimal avg = count == 0 ? BigDecimal.ZERO
                : total.divide(BigDecimal.valueOf(count), 0, RoundingMode.HALF_UP);

        return new RevenueReportResponse(total, count, avg, invoices);
    }

    /** Thong ke doanh thu nhom theo ngay trong khoang thoi gian (dung cho bieu do). */
    public Map<String, BigDecimal> getRevenueGroupedByDay(LocalDateTime from, LocalDateTime to) {
        List<Invoice> invoices = invoiceRepository.findByInvoiceTimeBetweenOrderByInvoiceTimeDesc(from, to);
        Map<String, BigDecimal> result = new TreeMap<>();
        for (Invoice inv : invoices) {
            String key = inv.getInvoiceTime().toLocalDate().toString();
            result.merge(key, inv.getTotalAmount(), BigDecimal::add);
        }
        return result;
    }

    /** Thong ke doanh thu nhom theo thang (yyyy-MM). */
    public Map<String, BigDecimal> getRevenueGroupedByMonth(LocalDateTime from, LocalDateTime to) {
        List<Invoice> invoices = invoiceRepository.findByInvoiceTimeBetweenOrderByInvoiceTimeDesc(from, to);
        Map<String, BigDecimal> result = new TreeMap<>();
        for (Invoice inv : invoices) {
            String key = inv.getInvoiceTime().getYear() + "-" + String.format("%02d", inv.getInvoiceTime().getMonthValue());
            result.merge(key, inv.getTotalAmount(), BigDecimal::add);
        }
        return result;
    }

    /** Thong ke doanh thu nhom theo nam. */
    public Map<String, BigDecimal> getRevenueGroupedByYear(LocalDateTime from, LocalDateTime to) {
        List<Invoice> invoices = invoiceRepository.findByInvoiceTimeBetweenOrderByInvoiceTimeDesc(from, to);
        Map<String, BigDecimal> result = new TreeMap<>();
        for (Invoice inv : invoices) {
            String key = String.valueOf(inv.getInvoiceTime().getYear());
            result.merge(key, inv.getTotalAmount(), BigDecimal::add);
        }
        return result;
    }

    /** San pham ban chay nhat trong khoang thoi gian, sap xep giam dan theo so luong ban. */
    public List<BestSellingProductResponse> getBestSellingProducts(LocalDateTime from, LocalDateTime to, int limit) {
        List<InvoiceDetail> details = invoiceDetailRepository.findByInvoiceTimeBetween(from, to);

        Map<Long, BestSellingProductResponse> grouped = new LinkedHashMap<>();
        for (InvoiceDetail d : details) {
            Product p = d.getProduct();
            BestSellingProductResponse cur = grouped.get(p.getId());
            BigDecimal lineTotal = d.getPrice().multiply(BigDecimal.valueOf(d.getQuantity()));
            if (cur == null) {
                grouped.put(p.getId(), new BestSellingProductResponse(p.getId(), p.getName(), (long) d.getQuantity(), lineTotal));
            } else {
                cur.setTotalQuantitySold(cur.getTotalQuantitySold() + d.getQuantity());
                cur.setTotalRevenue(cur.getTotalRevenue().add(lineTotal));
            }
        }

        return grouped.values().stream()
                .sorted((a, b) -> Long.compare(b.getTotalQuantitySold(), a.getTotalQuantitySold()))
                .limit(limit)
                .collect(Collectors.toList());
    }

    /** Thong ke doanh thu nhom theo tuan (yyyy-Www, chuan ISO). */
    public Map<String, BigDecimal> getRevenueGroupedByWeek(LocalDateTime from, LocalDateTime to) {
        List<Invoice> invoices = invoiceRepository.findByInvoiceTimeBetweenOrderByInvoiceTimeDesc(from, to);
        Map<String, BigDecimal> result = new TreeMap<>();
        java.time.temporal.WeekFields wf = java.time.temporal.WeekFields.ISO;
        for (Invoice inv : invoices) {
            java.time.LocalDate date = inv.getInvoiceTime().toLocalDate();
            int week = date.get(wf.weekOfWeekBasedYear());
            int year = date.get(wf.weekBasedYear());
            String key = year + "-W" + String.format("%02d", week);
            result.merge(key, inv.getTotalAmount(), BigDecimal::add);
        }
        return result;
    }

    /**
     * Bao cao doanh thu cho NHAN VIEN, chi tinh tren cac danh muc san pham
     * ma nhan vien do duoc phan cong quan ly. groupBy = day|week|month.
     * Doanh thu duoc tinh theo tung dong hoa don (InvoiceDetail) thay vi
     * ca hoa don, vi 1 hoa don co the gom nhieu danh muc khac nhau.
     */
    public Map<String, BigDecimal> getStaffRevenueGrouped(List<Long> categoryIds, LocalDateTime from, LocalDateTime to, String groupBy) {
        if (categoryIds == null || categoryIds.isEmpty()) return new TreeMap<>();
        List<InvoiceDetail> details = invoiceDetailRepository.findByInvoiceTimeBetweenAndCategoryIds(from, to, categoryIds);
        Map<String, BigDecimal> result = new TreeMap<>();
        java.time.temporal.WeekFields wf = java.time.temporal.WeekFields.ISO;

        for (InvoiceDetail d : details) {
            java.time.LocalDate date = d.getInvoice().getInvoiceTime().toLocalDate();
            String key;
            if ("month".equals(groupBy)) {
                key = date.getYear() + "-" + String.format("%02d", date.getMonthValue());
            } else if ("week".equals(groupBy)) {
                int week = date.get(wf.weekOfWeekBasedYear());
                int year = date.get(wf.weekBasedYear());
                key = year + "-W" + String.format("%02d", week);
            } else {
                key = date.toString();
            }
            BigDecimal lineTotal = d.getPrice().multiply(BigDecimal.valueOf(d.getQuantity()));
            result.merge(key, lineTotal, BigDecimal::add);
        }
        return result;
    }

    /** Tong doanh thu cua nhan vien tren cac danh muc duoc phan cong (dung cho the thong ke). */
    public BigDecimal getStaffTotalRevenue(List<Long> categoryIds, LocalDateTime from, LocalDateTime to) {
        if (categoryIds == null || categoryIds.isEmpty()) return BigDecimal.ZERO;
        List<InvoiceDetail> details = invoiceDetailRepository.findByInvoiceTimeBetweenAndCategoryIds(from, to, categoryIds);
        return details.stream()
                .map(d -> d.getPrice().multiply(BigDecimal.valueOf(d.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /** Danh sach san pham va tinh trang ton kho (dung de thong ke hang ton). */
    public List<Product> getInventoryReport() {
        return productRepository.findAll();
    }

    /** Danh sach san pham sap het hang (ton kho <= nguong). */
    public List<Product> getLowStockProducts(int threshold) {
        return productRepository.findByQuantityLessThanEqual(threshold);
    }
}

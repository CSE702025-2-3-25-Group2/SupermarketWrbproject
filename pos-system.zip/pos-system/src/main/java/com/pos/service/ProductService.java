package com.pos.service;

import com.pos.entity.Product;
import com.pos.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public List<Product> getAll() {
        return productRepository.findAll();
    }

    public Product getById(Long id) {
        return productRepository.findById(id).orElseThrow(() -> new RuntimeException("Khong tim thay san pham"));
    }

    public List<Product> search(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return productRepository.findAll();
        }
        return productRepository.findByNameContainingIgnoreCaseOrBarcodeContainingIgnoreCase(keyword, keyword);
    }

    public Product create(Product product) {
        return productRepository.save(product);
    }

    public Product update(Long id, Product payload) {
        Product product = getById(id);
        product.setBarcode(payload.getBarcode());
        product.setName(payload.getName());
        product.setCategory(payload.getCategory());
        product.setSupplier(payload.getSupplier());
        product.setPrice(payload.getPrice());
        product.setQuantity(payload.getQuantity());
        product.setUnit(payload.getUnit());
        return productRepository.save(product);
    }

    public void delete(Long id) {
        productRepository.deleteById(id);
    }

    // Ton kho thap (canh bao het hang) - mac dinh nguong 10
    public List<Product> lowStock(int threshold) {
        return productRepository.findByQuantityLessThanEqual(threshold);
    }

    // San pham thuoc cac danh muc duoc phan cong cho 1 nhan vien
    public List<Product> getByCategoryIds(List<Long> categoryIds) {
        if (categoryIds == null || categoryIds.isEmpty()) return List.of();
        return productRepository.findByCategoryIdIn(categoryIds);
    }
}

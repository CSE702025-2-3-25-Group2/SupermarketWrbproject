package com.pos.service;

import com.pos.dto.SaleRequest;
import com.pos.entity.*;
import com.pos.repository.CustomerRepository;
import com.pos.repository.InvoiceRepository;
import com.pos.repository.ProductRepository;
import com.pos.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class SaleService {

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private UserRepository userRepository;

    /**
     * Tao hoa don ban hang. Sau khi luu hoa don, tu dong tru so luong ton kho
     * cua tung san pham tuong ung. Neu san pham khong du hang se bao loi.
     */
    @Transactional
    public Invoice createSale(SaleRequest request) {
        if (request.getItems() == null || request.getItems().isEmpty()) {
            throw new RuntimeException("Hoa don khong co san pham nao");
        }

        Invoice invoice = new Invoice();
        invoice.setInvoiceTime(LocalDateTime.now());

        if (request.getCustomerId() != null) {
            Customer customer = customerRepository.findById(request.getCustomerId())
                    .orElse(null);
            invoice.setCustomer(customer);
        }
        if (request.getUserId() != null) {
            User user = userRepository.findById(request.getUserId()).orElse(null);
            invoice.setUser(user);
        }

        BigDecimal total = BigDecimal.ZERO;

        for (SaleRequest.SaleItem item : request.getItems()) {
            Product product = productRepository.findById(item.getProductId())
                    .orElseThrow(() -> new RuntimeException("San pham khong ton tai: " + item.getProductId()));

            if (product.getQuantity() < item.getQuantity()) {
                throw new RuntimeException("San pham '" + product.getName() + "' khong du ton kho (con " + product.getQuantity() + ")");
            }

            InvoiceDetail detail = new InvoiceDetail();
            detail.setInvoice(invoice);
            detail.setProduct(product);
            detail.setQuantity(item.getQuantity());
            detail.setPrice(product.getPrice());
            invoice.getDetails().add(detail);

            total = total.add(product.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())));

            // Tu dong cap nhat (tru) ton kho
            product.setQuantity(product.getQuantity() - item.getQuantity());
            productRepository.save(product);
        }

        invoice.setTotalAmount(total);
        return invoiceRepository.save(invoice);
    }

    public List<Invoice> getAll() {
        return invoiceRepository.findAllByOrderByInvoiceTimeDesc();
    }

    public Invoice getById(Long id) {
        return invoiceRepository.findById(id).orElseThrow(() -> new RuntimeException("Khong tim thay hoa don"));
    }

    public List<Invoice> getByDateRange(LocalDateTime from, LocalDateTime to) {
        return invoiceRepository.findByInvoiceTimeBetweenOrderByInvoiceTimeDesc(from, to);
    }
}

package com.pos.service;

import com.pos.dto.LoginRequest;
import com.pos.dto.LoginResponse;
import com.pos.entity.User;
import com.pos.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public LoginResponse login(LoginRequest request) {
        Optional<User> userOpt = userRepository.findByUsername(request.getUsername());
        if (userOpt.isEmpty()) {
            return LoginResponse.fail("Tai khoan khong ton tai");
        }
        User user = userOpt.get();
        if (!user.getPassword().equals(request.getPassword())) {
            return LoginResponse.fail("Sai mat khau");
        }
        return LoginResponse.ok(user);
    }

    public List<User> getAll() {
        return userRepository.findAll();
    }

    public User getById(Long id) {
        return userRepository.findById(id).orElseThrow(() -> new RuntimeException("Khong tim thay nhan vien"));
    }

    public User create(User user) {
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new RuntimeException("Ten dang nhap da ton tai");
        }
        return userRepository.save(user);
    }

    public User update(Long id, User payload) {
        User user = getById(id);
        user.setFullName(payload.getFullName());
        user.setPhone(payload.getPhone());
        user.setEmail(payload.getEmail());
        user.setRole(payload.getRole());
        if (payload.getPassword() != null && !payload.getPassword().isBlank()) {
            user.setPassword(payload.getPassword());
        }
        return userRepository.save(user);
    }

    public void delete(Long id) {
        userRepository.deleteById(id);
    }
}

package com.pos.service;

import com.pos.entity.Category;
import com.pos.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;

    public List<Category> getAll() { return categoryRepository.findAll(); }
    public Category create(Category c) { return categoryRepository.save(c); }
    public Category update(Long id, Category payload) {
        Category c = categoryRepository.findById(id).orElseThrow(() -> new RuntimeException("Khong tim thay danh muc"));
        c.setName(payload.getName());
        c.setDescription(payload.getDescription());
        return categoryRepository.save(c);
    }
    public void delete(Long id) { categoryRepository.deleteById(id); }
}

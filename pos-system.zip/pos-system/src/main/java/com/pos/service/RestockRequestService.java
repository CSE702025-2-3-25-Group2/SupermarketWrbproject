package com.pos.service;

import com.pos.dto.RestockRequestDTO;
import com.pos.dto.StockImportRequest;
import com.pos.entity.Product;
import com.pos.entity.RestockRequest;
import com.pos.entity.User;
import com.pos.repository.ProductRepository;
import com.pos.repository.RestockRequestRepository;
import com.pos.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@Service
public class RestockRequestService {

    @Autowired
    private RestockRequestRepository restockRequestRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StockImportService stockImportService;

    // Nhan vien tao de xuat nhap hang gui cho admin
    public RestockRequest create(RestockRequestDTO dto) {
        if (dto.getQuantity() == null || dto.getQuantity() <= 0) {
            throw new RuntimeException("Số lượng đề xuất phải lớn hơn 0");
        }
        Product product = productRepository.findById(dto.getProductId())
                .orElseThrow(() -> new RuntimeException("Sản phẩm không tồn tại"));
        User staff = userRepository.findById(dto.getUserId())
                .orElseThrow(() -> new RuntimeException("Không tìm thấy nhân viên"));

        RestockRequest request = new RestockRequest();
        request.setProduct(product);
        request.setProposedBy(staff);
        request.setQuantity(dto.getQuantity());
        request.setNote(dto.getNote());
        request.setStatus(RestockRequest.Status.PENDING);
        return restockRequestRepository.save(request);
    }

    public List<RestockRequest> getAll() {
        return restockRequestRepository.findAllByOrderByCreatedAtDesc();
    }

    public List<RestockRequest> getPending() {
        return restockRequestRepository.findByStatusOrderByCreatedAtDesc(RestockRequest.Status.PENDING);
    }

    public List<RestockRequest> getByUser(Long userId) {
        return restockRequestRepository.findByProposedByIdOrderByCreatedAtDesc(userId);
    }

    /**
     * Admin duyet de xuat: tu dong tao 1 phieu nhap kho (StockImport) tuong ung,
     * qua do tan dung logic cong ton kho co san trong StockImportService.
     */
    @Transactional
    public RestockRequest approve(Long requestId, Long adminUserId) {
        RestockRequest request = getPendingOrThrow(requestId);
        User admin = userRepository.findById(adminUserId).orElseThrow(() -> new RuntimeException("Không tìm thấy quản trị viên"));

        StockImportRequest importReq = new StockImportRequest();
        importReq.setUserId(adminUserId);
        importReq.setSupplierId(request.getProduct().getSupplier() != null ? request.getProduct().getSupplier().getId() : null);
        StockImportRequest.ImportItem item = new StockImportRequest.ImportItem();
        item.setProductId(request.getProduct().getId());
        item.setQuantity(request.getQuantity());
        item.setPrice(request.getProduct().getPrice()); // gia tham khao = gia ban hien tai
        importReq.setItems(Collections.singletonList(item));
        stockImportService.createImport(importReq);

        request.setStatus(RestockRequest.Status.APPROVED);
        request.setProcessedBy(admin);
        request.setProcessedAt(LocalDateTime.now());
        return restockRequestRepository.save(request);
    }

    public RestockRequest reject(Long requestId, Long adminUserId) {
        RestockRequest request = getPendingOrThrow(requestId);
        User admin = userRepository.findById(adminUserId).orElseThrow(() -> new RuntimeException("Không tìm thấy quản trị viên"));

        request.setStatus(RestockRequest.Status.REJECTED);
        request.setProcessedBy(admin);
        request.setProcessedAt(LocalDateTime.now());
        return restockRequestRepository.save(request);
    }

    private RestockRequest getPendingOrThrow(Long id) {
        RestockRequest request = restockRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy đề xuất"));
        if (request.getStatus() != RestockRequest.Status.PENDING) {
            throw new RuntimeException("Đề xuất này đã được xử lý trước đó");
        }
        return request;
    }
}

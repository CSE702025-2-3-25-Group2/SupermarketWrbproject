package com.pos.service;

import com.pos.dto.StockImportRequest;
import com.pos.entity.*;
import com.pos.repository.ProductRepository;
import com.pos.repository.StockImportRepository;
import com.pos.repository.SupplierRepository;
import com.pos.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class StockImportService {

    @Autowired
    private StockImportRepository stockImportRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private SupplierRepository supplierRepository;

    @Autowired
    private UserRepository userRepository;

    /**
     * Tao phieu nhap hang. Sau khi luu, tu dong cong them so luong ton kho
     * cho tung san pham tuong ung.
     */
    @Transactional
    public StockImport createImport(StockImportRequest request) {
        if (request.getItems() == null || request.getItems().isEmpty()) {
            throw new RuntimeException("Phieu nhap khong co san pham nao");
        }

        StockImport stockImport = new StockImport();
        stockImport.setImportTime(LocalDateTime.now());

        if (request.getSupplierId() != null) {
            Supplier supplier = supplierRepository.findById(request.getSupplierId()).orElse(null);
            stockImport.setSupplier(supplier);
        }
        if (request.getUserId() != null) {
            User user = userRepository.findById(request.getUserId()).orElse(null);
            stockImport.setUser(user);
        }

        BigDecimal total = BigDecimal.ZERO;

        for (StockImportRequest.ImportItem item : request.getItems()) {
            Product product = productRepository.findById(item.getProductId())
                    .orElseThrow(() -> new RuntimeException("San pham khong ton tai: " + item.getProductId()));

            StockImportDetail detail = new StockImportDetail();
            detail.setStockImport(stockImport);
            detail.setProduct(product);
            detail.setQuantity(item.getQuantity());
            detail.setPrice(item.getPrice());
            stockImport.getDetails().add(detail);

            total = total.add(item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())));

            // Tu dong cap nhat (cong) ton kho
            product.setQuantity(product.getQuantity() + item.getQuantity());
            productRepository.save(product);
        }

        stockImport.setTotalAmount(total);
        return stockImportRepository.save(stockImport);
    }

    public List<StockImport> getAll() {
        return stockImportRepository.findAllByOrderByImportTimeDesc();
    }

    public StockImport getById(Long id) {
        return stockImportRepository.findById(id).orElseThrow(() -> new RuntimeException("Khong tim thay phieu nhap"));
    }
}

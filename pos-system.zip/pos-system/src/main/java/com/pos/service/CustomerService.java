package com.pos.service;

import com.pos.entity.Customer;
import com.pos.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    public List<Customer> getAll() { return customerRepository.findAll(); }

    public List<Customer> search(String keyword) {
        if (keyword == null || keyword.isBlank()) return customerRepository.findAll();
        return customerRepository.findByNameContainingIgnoreCaseOrPhoneContainingIgnoreCase(keyword, keyword);
    }

    public Customer create(Customer c) { return customerRepository.save(c); }

    public Customer update(Long id, Customer payload) {
        Customer c = customerRepository.findById(id).orElseThrow(() -> new RuntimeException("Khong tim thay khach hang"));
        c.setName(payload.getName());
        c.setPhone(payload.getPhone());
        c.setAddress(payload.getAddress());
        return customerRepository.save(c);
    }

    public void delete(Long id) { customerRepository.deleteById(id); }
}

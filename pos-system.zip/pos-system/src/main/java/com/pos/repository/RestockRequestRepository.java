package com.pos.repository;

import com.pos.entity.RestockRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RestockRequestRepository extends JpaRepository<RestockRequest, Long> {
    List<RestockRequest> findAllByOrderByCreatedAtDesc();
    List<RestockRequest> findByStatusOrderByCreatedAtDesc(RestockRequest.Status status);
    List<RestockRequest> findByProposedByIdOrderByCreatedAtDesc(Long userId);
}

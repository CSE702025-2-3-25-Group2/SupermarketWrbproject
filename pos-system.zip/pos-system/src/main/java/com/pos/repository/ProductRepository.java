package com.pos.repository;

import com.pos.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByNameContainingIgnoreCaseOrBarcodeContainingIgnoreCase(String name, String barcode);
    Product findByBarcode(String barcode);
    List<Product> findByQuantityLessThanEqual(Integer quantity);
    List<Product> findByCategoryIdIn(List<Long> categoryIds);
}

package com.pos.repository;

import com.pos.entity.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    List<Invoice> findByInvoiceTimeBetweenOrderByInvoiceTimeDesc(LocalDateTime from, LocalDateTime to);
    List<Invoice> findAllByOrderByInvoiceTimeDesc();
}

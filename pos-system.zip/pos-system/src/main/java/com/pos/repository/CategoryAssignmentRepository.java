package com.pos.repository;

import com.pos.entity.CategoryAssignment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CategoryAssignmentRepository extends JpaRepository<CategoryAssignment, Long> {
    List<CategoryAssignment> findByUserId(Long userId);
    List<CategoryAssignment> findByCategoryId(Long categoryId);
    Optional<CategoryAssignment> findByUserIdAndCategoryId(Long userId, Long categoryId);
}

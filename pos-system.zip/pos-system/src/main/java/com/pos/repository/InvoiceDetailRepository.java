package com.pos.repository;

import com.pos.entity.InvoiceDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

public interface InvoiceDetailRepository extends JpaRepository<InvoiceDetail, Long> {
    @Query("SELECT d FROM InvoiceDetail d WHERE d.invoice.invoiceTime BETWEEN :from AND :to")
    List<InvoiceDetail> findByInvoiceTimeBetween(LocalDateTime from, LocalDateTime to);

    // JOIN FETCH d.invoice de tranh LazyInitializationException khi doc invoiceTime sau khi query tra ve
    @Query("SELECT d FROM InvoiceDetail d JOIN FETCH d.invoice i WHERE i.invoiceTime BETWEEN :from AND :to AND d.product.category.id IN :categoryIds")
    List<InvoiceDetail> findByInvoiceTimeBetweenAndCategoryIds(LocalDateTime from, LocalDateTime to, java.util.List<Long> categoryIds);
}

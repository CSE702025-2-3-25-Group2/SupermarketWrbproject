package com.pos.repository;

import com.pos.entity.StockImport;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StockImportRepository extends JpaRepository<StockImport, Long> {
    List<StockImport> findAllByOrderByImportTimeDesc();
}
